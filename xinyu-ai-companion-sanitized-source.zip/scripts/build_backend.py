"""PyInstaller 打包后端 → backend/pkg/backend/backend.exe（供 electron-builder 引用）"""
import subprocess
import sys
import os
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent / "backend"
ROOT = BACKEND.parent
FRONTEND_DIST = ROOT / "frontend" / "dist"
OUT = BACKEND / "pkg"
WORK = BACKEND / "build" / "pyi"


def main():
    if not (FRONTEND_DIST / "index.html").exists():
        print("!! 请先构建前端：cd frontend && npm run build")
        sys.exit(1)
    args = [
        sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
        "--name", "backend", "--onedir",
        "--distpath", str(OUT), "--workpath", str(WORK), "--specpath", str(WORK),
        "--collect-all", "edge_tts",
        "--paths", str(BACKEND),
        "--collect-all", "sherpa_onnx",
        "--collect-all", "av",
        "--exclude-module", "faster_whisper",
        "--exclude-module", "ctranslate2",
        "--exclude-module", "tokenizers",
        "--exclude-module", "onnxruntime",
        "--collect-submodules", "uvicorn",
        "--collect-submodules", "fastapi",
        "--hidden-import", "uvicorn.logging",
        "--hidden-import", "uvicorn.loops.auto",
        "--hidden-import", "uvicorn.loops.asyncio",
        "--hidden-import", "uvicorn.protocols.http.auto",
        "--hidden-import", "uvicorn.protocols.http.h11_impl",
        "--hidden-import", "uvicorn.protocols.websockets.auto",
        "--hidden-import", "uvicorn.lifespan.on",
        "--hidden-import", "uvicorn.lifespan.off",
        "--copy-metadata", "edge_tts",
        "--copy-metadata", "fastapi",
        "--copy-metadata", "uvicorn",
        "--exclude-module", "tkinter",
        "--exclude-module", "matplotlib",
        "--add-data", f"{FRONTEND_DIST};frontend_dist",
        "--add-data", f"{BACKEND / 'models' / 'sensevoice'};models/sensevoice",
        "--add-data", f"{BACKEND / 'models' / 'silero_vad.onnx'};models",
        "--add-data", f"{ROOT / 'docs' / 'third-party'};third-party",
        "main.py",
    ]
    print(">>", " ".join(args[:6]), "...")
    env = os.environ.copy()
    env['PYTHONPATH'] = str(BACKEND)
    env['TEMP'] = str(ROOT / '.cache' / 'build-tmp')
    env['TMP'] = env['TEMP']
    Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
    r = subprocess.run(args, cwd=BACKEND, env=env)
    if r.returncode != 0:
        print("!! PyInstaller 失败")
        sys.exit(r.returncode)
    exe = OUT / "backend" / "backend.exe"
    print("OK:", exe, "exists:", exe.exists())


if __name__ == "__main__":
    main()
