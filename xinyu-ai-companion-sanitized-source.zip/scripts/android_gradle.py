from pathlib import Path
import hashlib,urllib.request,zipfile,subprocess,sys,os
ROOT=Path(__file__).resolve().parents[1]
VERSION="8.9"
URL=f"https://services.gradle.org/distributions/gradle-{VERSION}-bin.zip"
def main():
    cache=ROOT/".cache"/"gradle";cache.mkdir(parents=True,exist_ok=True)
    archive=cache/f"gradle-{VERSION}-bin.zip"
    expected=urllib.request.urlopen(URL+".sha256",timeout=60).read().decode().strip().split()[0]
    def digest():
        h=hashlib.sha256()
        with archive.open("rb") as f:
            for b in iter(lambda:f.read(1048576),b""):h.update(b)
        return h.hexdigest()
    if not archive.exists() or digest()!=expected:
        with urllib.request.urlopen(URL,timeout=120) as r,archive.open("wb") as f:
            import shutil;shutil.copyfileobj(r,f)
    if digest()!=expected:raise RuntimeError("Gradle checksum mismatch")
    target=cache/f"gradle-{VERSION}"
    if not target.exists():
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                resolved=(cache/member.filename).resolve()
                if cache.resolve() not in resolved.parents:raise RuntimeError("Unsafe archive path")
            z.extractall(cache)
    env=os.environ.copy();env["GRADLE_USER_HOME"]=str(ROOT/".cache"/"gradle-home")
    command=target/"bin"/("gradle.bat" if os.name=="nt" else "gradle")
    if os.name!="nt":command.chmod(command.stat().st_mode|0o111)
    subprocess.run([str(command),*sys.argv[1:]],cwd=ROOT/"android",env=env,check=True)
if __name__=="__main__":main()
