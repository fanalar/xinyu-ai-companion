"""Download pinned public speech assets, verify SHA256, extract only named files."""
from pathlib import Path
import hashlib, shutil, tarfile, urllib.request

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / '.cache' / 'speech-downloads'
SENSEVOICE = ('https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17.tar.bz2', '7d1efa2138a65b0b488df37f8b89e3d91a60676e416f515b952358d83dfd347e')
SILERO = ('https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx', '9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6')
AAR = ('https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-1.13.8.aar', '633c24321e06b1fe79feafa03ea16cbc0f8a286641e2da3559bac91bdb13bd96')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''): h.update(block)
    return h.hexdigest()

def download(name, resource):
    CACHE.mkdir(parents=True, exist_ok=True)
    path = CACHE / name
    if not path.exists() or digest(path) != resource[1]:
        request = urllib.request.Request(resource[0], headers={'User-Agent':'OpenSourceModelSetup/1.0'})
        with urllib.request.urlopen(request, timeout=90) as response, path.open('wb') as target:
            shutil.copyfileobj(response, target)
    if digest(path) != resource[1]: raise RuntimeError('Model checksum mismatch; downloaded file is not used')
    return path

def main(android=False):
    archive = download('sensevoice.tar.bz2', SENSEVOICE)
    destination = ROOT / ('android/app/src/main/assets/speech-hq' if android else 'backend/models/sensevoice')
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, 'r:bz2') as bundle:
        for filename in ('model.int8.onnx', 'tokens.txt'):
            member = next(m for m in bundle.getmembers() if m.isfile() and m.name.endswith('/'+filename))
            with bundle.extractfile(member) as source, (destination/filename).open('wb') as target:
                shutil.copyfileobj(source, target)
    silero = download('silero_vad.onnx', SILERO)
    target = destination/'silero_vad.onnx' if android else ROOT/'backend/models/silero_vad.onnx'
    shutil.copy2(silero, target)
    if android:
        libs=ROOT/'android/app/libs';libs.mkdir(parents=True,exist_ok=True)
        shutil.copy2(download('sherpa-onnx.aar', AAR), libs/'sherpa-onnx.aar')
    print('Pinned speech assets prepared; licenses are in docs/third-party')

if __name__ == '__main__':
    import sys
    main('--android' in sys.argv)
