from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/"android/frontend/dist"
if not (source/"index.html").exists():raise SystemExit("Build android/frontend with npm ci && npm run build first")
target=ROOT/"android/app/src/main/assets/web"
target.mkdir(parents=True,exist_ok=True)
shutil.copytree(source,target,dirs_exist_ok=True)
print("Mobile UI prepared")
