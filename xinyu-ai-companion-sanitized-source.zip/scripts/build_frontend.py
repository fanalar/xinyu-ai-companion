from pathlib import Path
import os,subprocess
root=Path(__file__).resolve().parents[1]
subprocess.run(["npm.cmd" if os.name=="nt" else "npm","ci"],cwd=root/"frontend",check=True)
subprocess.run(["npm.cmd" if os.name=="nt" else "npm","run","build"],cwd=root/"frontend",check=True)
