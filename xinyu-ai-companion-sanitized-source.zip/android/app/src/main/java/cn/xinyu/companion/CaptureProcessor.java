package cn.xinyu.companion;
import java.util.function.BooleanSupplier;import java.util.function.Supplier;
import com.k2fsa.sherpa.onnx.Vad;
/** Shared production PCM: speaker exclusion -> neural speech VAD -> whole-utterance ASR. */
final class CaptureProcessor implements AutoCloseable {
 interface Sink{void emit(String type,Object value);}
 final SpeechGate gate;final ChineseSpeechEngine model;final Sink sink;final Vad vad;
 final BooleanSupplier speaking;final Supplier<String> spoken;final int silence;
 volatile boolean closed=false;boolean started=false,blocked=false,captureReported=false;
 volatile long decodedFrames=0,discardedFrames=0,turn=0;long recognizedRevision,lastLevel=0;
 CaptureProcessor(ChineseSpeechEngine model,SpeechGate gate,int silence,BooleanSupplier speaking,Supplier<String> spoken,Sink sink){this.model=model;this.gate=gate;this.silence=silence;this.speaking=speaking;this.spoken=spoken;this.sink=sink;vad=model.vad(silence);recognizedRevision=gate.revision();}
 void feed(short[] pcm,int n,long frameRevision,long now){
  if(closed||n<=0)return;boolean discard=gate.discard(frameRevision,now);
  if(discard||recognizedRevision!=frameRevision){vad.reset();vad.clear();started=false;turn++;recognizedRevision=gate.revision();}
  if(discard){discardedFrames++;if(!blocked||!captureReported){sink.emit("capture",false);sink.emit("level",0);blocked=true;captureReported=true;}return;}
  if(blocked||!captureReported){sink.emit("capture",true);blocked=false;captureReported=true;}
  float[] samples=new float[n];double sum=0;for(int i=0;i<n;i++){samples[i]=pcm[i]/32768f;sum+=samples[i]*samples[i];}
  if(now-lastLevel>140){sink.emit("level",Math.min(1,Math.sqrt(sum/n)*12));lastLevel=now;}
  decodedFrames++;vad.acceptWaveform(ChineseSpeechEngine.normalized(samples,32));
  if(vad.isSpeechDetected()&&!started&&!gate.discard(frameRevision,now)){started=true;turn++;sink.emit("start",true);}
  while(!vad.empty()){
   float[] utterance=vad.front().getSamples();vad.pop();started=false;
   final long owner=turn,revision=frameRevision;sink.emit("processing",true);
   model.submit(()->{
    if(closed||owner!=turn||gate.discard(revision,android.os.SystemClock.elapsedRealtime()))return;
    try{String text=model.recognize(utterance);if(closed||owner!=turn||gate.discard(revision,android.os.SystemClock.elapsedRealtime()))return;if(!text.isEmpty()&&!MainActivity.isPathological(text))sink.emit("text",text);else sink.emit("empty",true);}
    catch(Exception e){if(!closed&&owner==turn)sink.emit("error","语音识别未完成，请再说一次或暂时打字");}
   });
  }
 }
 public void close(){closed=true;turn++;vad.release();}
}
