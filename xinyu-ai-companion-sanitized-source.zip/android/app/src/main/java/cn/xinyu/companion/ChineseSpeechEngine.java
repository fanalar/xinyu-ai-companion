package cn.xinyu.companion;
import com.k2fsa.sherpa.onnx.*;
import java.util.concurrent.*;
/** On-device model, neural VAD and bounded decoding; audio is never saved. */
final class ChineseSpeechEngine implements AutoCloseable {
 final OfflineRecognizer recognizer;final String vadPath;
 final ThreadPoolExecutor worker=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<Runnable>(2));
 volatile boolean closed;
 ChineseSpeechEngine(String directory){
  OfflineRecognizerConfig config=new OfflineRecognizerConfig();OfflineModelConfig model=config.getModelConfig();
  model.getSenseVoice().setModel(directory+"/model.int8.onnx");model.getSenseVoice().setLanguage("zh");model.getSenseVoice().setUseInverseTextNormalization(true);
  model.setTokens(directory+"/tokens.txt");model.setNumThreads(2);model.setProvider("cpu");model.setDebug(false);vadPath=directory+"/silero_vad.onnx";recognizer=new OfflineRecognizer(null,config);
 }
 Vad vad(int silence){VadModelConfig c=new VadModelConfig();SileroVadModelConfig v=c.getSileroVadModelConfig();v.setModel(vadPath);v.setThreshold(.45f);v.setMinSilenceDuration(silence/1000f);v.setMinSpeechDuration(.18f);v.setMaxSpeechDuration(30);c.setNumThreads(1);return new Vad(null,c);}
 static float[] normalized(float[] samples,float maximumGain){
  double sum=0;float peak=0;for(float x:samples){sum+=x*x;peak=Math.max(peak,Math.abs(x));}
  double rms=Math.sqrt(sum/Math.max(1,samples.length));float gain=(float)Math.min(maximumGain,.08/Math.max(.00001,rms));if(peak>0)gain=Math.min(gain,.95f/peak);
  float[] result=new float[samples.length];for(int i=0;i<samples.length;i++)result[i]=samples[i]*gain;return result;
 }
 String recognize(float[] samples){synchronized(recognizer){if(closed)return "";OfflineStream stream=recognizer.createStream();try{stream.acceptWaveform(normalized(samples,4),16000);recognizer.decode(stream);return recognizer.getResult(stream).getText().replaceAll("<\\|[^>]+\\|>","").trim();}finally{stream.release();}}}
 void submit(Runnable task){if(closed)return;try{worker.execute(task);}catch(RejectedExecutionException e){if(!closed){worker.getQueue().poll();try{worker.execute(task);}catch(RejectedExecutionException ignored){}}}}
 public void close(){closed=true;worker.getQueue().clear();try{worker.execute(()->{synchronized(recognizer){recognizer.release();}});}catch(RejectedExecutionException ignored){}worker.shutdown();}
}
