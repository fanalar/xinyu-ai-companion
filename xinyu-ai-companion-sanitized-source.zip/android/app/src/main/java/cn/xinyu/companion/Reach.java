package cn.xinyu.companion;

import org.json.*;
import org.xmlpull.v1.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Android adaptation of Agent-Reach public channels, MIT, commit a19a171.
 * Upstream web.py and utils/url.py supply routing and validation behaviour.
 * No Python CLI, browser sessions, cookies, remote commands, or paid agent_run.
 */
class Reach {
  static final String COMMIT="a19a171fa980a0785849596492e0af4db800c82f";
  final MainActivity app;
  final ConcurrentHashMap<String,JSONObject> last=new ConcurrentHashMap<>();
  Reach(MainActivity app){this.app=app;}
  static String publicUrl(String text)throws Exception {
    String s=text==null?"":text.trim();if(!s.contains("://"))s="https://"+s;
    if(s.length()>2000||s.contains("\\")||s.matches(".*[\\s\\x00-\\x1f\\x7f].*"))throw new IOException("请提供公开网页的HTTPS链接");
    URI u=new URI(s);String h=u.getHost();int port=u.getPort();
    if(!"https".equals(u.getScheme())||h==null||u.getUserInfo()!=null||port!=-1&&port!=443||u.getFragment()!=null)throw new IOException("只读取公开HTTPS网页，请移除登录信息与片段");
    h=h.toLowerCase(Locale.ROOT).replaceAll("\\.$","");
    if(!h.contains(".")||h.matches("[0-9.]+")||h.contains(":")||h.startsWith("0x")||h.matches(".*\\.(local|localhost|localdomain|internal|lan|home\\.arpa)$")||h.equals("metadata.google.internal"))throw new IOException("不读取本机、内网或系统地址");
    String q=u.getRawQuery();if(q!=null&&URLDecoder.decode(q,"UTF-8").toLowerCase(Locale.ROOT).matches(".*(^|[&])(access_token|token|api_key|apikey|password|session|authorization|signature|sig|cookie|auth|key)=.*"))throw new IOException("链接含登录或签名参数，请使用公开分享链接");
    return s;
  }
  static void publicDns(String url)throws Exception {
    for(InetAddress ip:InetAddress.getAllByName(new URI(url).getHost())){
      byte[] b=ip.getAddress();boolean reserved=b.length==4&&((b[0]&255)==0||(b[0]&255)>=224||((b[0]&255)==100&&(b[1]&255)>=64&&(b[1]&255)<=127)||((b[0]&255)==198&&((b[1]&255)==18||(b[1]&255)==19)));
      if(ip.isAnyLocalAddress()||ip.isLoopbackAddress()||ip.isLinkLocalAddress()||ip.isSiteLocalAddress()||ip.isMulticastAddress()||reserved||b.length==16&&((b[0]&0xfe)==0xfc))throw new IOException("网页解析到内网地址，未读取");
    }
  }
  static boolean challenge(String body){String s=body.substring(0,Math.min(4096,body.length())).toLowerCase(Locale.ROOT);return s.contains("warning:")&&s.contains("requiring captcha")&&(s.contains("title: just a moment")||s.contains("performing security verification"))||s.contains("title: attention required! | cloudflare")&&(s.contains("ray id")||s.contains("/cdn-cgi/challenge-platform/"));}
  static String readerText(String s){return s.replaceAll("!\\[[^\\]]*\\]\\([^\\n]+\\)","").replaceAll("\\[([^\\]]+)\\]\\([^\\n)]+\\)","$1").replaceAll("(?m)^#{1,6}\\s*","").replaceAll("\\n{4,}","\n\n").trim();}
  String fetch(String url,JSONObject post,MainActivity.Job job,boolean dynamic,String accept)throws Exception {
    String current=url;
    for(int n=0;n<4;n++){
      if(job.cancelled)throw new IOException("已打断");if(dynamic){current=publicUrl(current);publicDns(current);}
      HttpURLConnection c=(HttpURLConnection)new URL(current).openConnection();job.conn=c;
      try{
        c.setConnectTimeout(7000);c.setReadTimeout(22000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setRequestProperty("User-Agent","XinyuPersonalAndroid/1.3.3 Agent-Reach-Android");c.setRequestProperty("Accept",accept);c.setRequestProperty("Cache-Control","no-cache");
        if(post!=null){c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(post.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode();
        if(dynamic&&post==null&&Arrays.asList(301,302,303,307,308).contains(code)){String location=c.getHeaderField("Location");if(location==null)throw new IOException("来源跳转地址无效");current=new URI(current).resolve(location).toString();continue;}
        if(code==429)throw new IOException("来源免费额度或频率受限，请稍后重试");
        if(code==401||code==403)throw new IOException("来源拒绝访问，已保留其他可用来源");
        if(code!=200)throw new IOException("来源暂时不可达（HTTP "+code+"）");
        return app.read(c.getInputStream(),job,2000000);
      }finally{job.conn=null;c.disconnect();}
    }throw new IOException("网页跳转过多，未读取");
  }
  void mark(String id,boolean ok,String note){try{last.put(id,new JSONObject().put("id",id).put("status",ok?"ok":"error").put("note",note).put("checked_at",java.time.Instant.now().toString()));}catch(Exception ignored){}}
  JSONObject status()throws Exception {
    JSONArray channels=new JSONArray();String[][] definitions={{"search","公开网页搜索","Exa MCP"},{"web","网页阅读","Jina Reader"},{"github","GitHub公开项目","GitHub公开API"},{"bilibili","B站视频搜索","B站公开搜索API"},{"v2ex","V2EX热门讨论","V2EX公开API"},{"rss","更多新闻来源","RSS/Atom"}};
    for(String[] d:definitions){JSONObject row=new JSONObject().put("id",d[0]).put("label",d[1]).put("backend",d[2]);JSONObject s=last.get(d[0]);row.put("status",s==null?"unchecked":s.get("status")).put("note",s==null?"尚未检查":s.get("note"));if(s!=null)row.put("checked_at",s.get("checked_at"));channels.put(row);}
    return new JSONObject().put("implementation","Agent-Reach Android public-channel adaptation").put("upstream_commit",COMMIT).put("channels",channels);
  }
  static JSONObject rpc(String raw)throws Exception {
    if(raw.trim().startsWith("{"))return new JSONObject(raw);
    StringBuilder data=new StringBuilder();for(String line:raw.split("\\r?\\n")){
      if(line.startsWith("data:")){if(data.length()>0)data.append('\n');data.append(line.substring(5).trim());}
      else if(line.trim().isEmpty()&&data.length()>0){try{JSONObject obj=new JSONObject(data.toString());if(obj.has("result")||obj.has("error"))return obj;}catch(JSONException ignored){}data.setLength(0);}
    }
    if(data.length()>0)return new JSONObject(data.toString());throw new IOException("搜索来源格式变化，未取得结果");
  }
  static JSONArray exaItems(JSONObject root)throws Exception {
    if(root.has("error"))throw new IOException("搜索服务拒绝或限制了请求");JSONObject r=root.optJSONObject("result");if(r==null||r.optBoolean("isError"))throw new IOException("搜索未返回有效结果");
    JSONArray out=new JSONArray();JSONObject structured=r.optJSONObject("structuredContent");JSONArray entries=structured==null?null:structured.optJSONArray("results");
    if(entries!=null){for(int n=0;n<Math.min(12,entries.length());n++){JSONObject e=entries.getJSONObject(n);String url=e.optString("url");try{publicUrl(url);}catch(Exception ignored){continue;}out.put(new JSONObject().put("title",MainActivity.clean(e.optString("title"),180)).put("url",url).put("publisher",new URI(url).getHost()).put("published_at",stamp(e.optString("publishedDate"))).put("snippet",MainActivity.clean(e.optString("text"),350)).put("aggregator",true));}return out;}
    JSONArray content=r.optJSONArray("content");if(content==null)return out;StringBuilder body=new StringBuilder();for(int n=0;n<content.length();n++)body.append(content.getJSONObject(n).optString("text")).append('\n');
    Map<String,String> item=new HashMap<>();String lastField="";
    for(String line:body.toString().split("\\r?\\n")){
      if(line.startsWith("Title:")){addExa(out,item);item=new HashMap<>();item.put("title",line.substring(6).trim());lastField="";}
      else if(line.startsWith("URL:")){item.put("url",line.substring(4).trim());lastField="";}
      else if(line.matches("(?i)Published (Date|Time):.*")){item.put("date",line.substring(line.indexOf(':')+1).trim());lastField="";}
      else if(line.startsWith("Text:")||line.startsWith("Highlights:")){item.put("snippet",line.substring(line.indexOf(':')+1).trim());lastField="snippet";}
      else if(lastField.equals("snippet")&&item.getOrDefault("snippet","").length()<350)item.put("snippet",item.getOrDefault("snippet","")+" "+line);
    }addExa(out,item);return out;
  }
  static void addExa(JSONArray out,Map<String,String> it)throws Exception {
    String url=it.getOrDefault("url",""),title=it.getOrDefault("title","");if(title.isEmpty()||out.length()>=12)return;
    try{publicUrl(url);}catch(Exception ignored){return;}
    out.put(new JSONObject().put("title",MainActivity.clean(title,180)).put("url",url).put("publisher",new URI(url).getHost()).put("published_at",stamp(it.getOrDefault("date",""))).put("snippet",MainActivity.clean(it.getOrDefault("snippet",""),350)).put("aggregator",true));
  }
  static Object stamp(String s){try{return java.time.Instant.parse(s).toString();}catch(Exception ignored){}try{return java.time.OffsetDateTime.parse(s).toInstant().toString();}catch(Exception ignored){}try{return java.time.LocalDate.parse(s).atStartOfDay().toInstant(java.time.ZoneOffset.ofHours(8)).toString();}catch(Exception ignored){}return MainActivity.date(s);}
  JSONArray search(JSONObject body,MainActivity.Job job)throws Exception {
    try{String q=body.optString("query").trim();if(q.isEmpty()||q.length()>500)throw new IOException("搜索关键词为空或过长");JSONObject args=new JSONObject().put("query",q).put("numResults",6).put("objective","Return relevant public pages with original URLs and publication dates; exclude directories, advertisements, and login pages.");
      JSONObject request=new JSONObject().put("jsonrpc","2.0").put("id",1).put("method","tools/call").put("params",new JSONObject().put("name","web_search_exa").put("arguments",args));JSONArray items=exaItems(rpc(fetch("https://mcp.exa.ai/mcp",request,job,false,"application/json, text/event-stream")));if(items.length()==0)throw new IOException("搜索未取得可引用的结果");mark("search",true,"实际搜索返回"+items.length()+"条公开结果");return items;
    }catch(Exception e){mark("search",false,app.friendly(e));throw e;}
  }
  JSONObject read(JSONObject body,MainActivity.Job job)throws Exception {
    try{String url=publicUrl(body.optString("url"));publicDns(url);String raw,reader="Jina Reader";
      try{raw=fetch("https://r.jina.ai/"+url,null,job,false,"application/json");}
      catch(SocketTimeoutException|UnknownHostException|ConnectException e){
        if(job.cancelled)throw e;
        JSONObject request=new JSONObject().put("jsonrpc","2.0").put("id",1).put("method","tools/call").put("params",new JSONObject().put("name","web_fetch_exa").put("arguments",new JSONObject().put("urls",new JSONArray().put(url)).put("maxCharacters",6000)));
        JSONObject response=rpc(fetch("https://mcp.exa.ai/mcp",request,job,false,"application/json, text/event-stream")),result=response.optJSONObject("result");
        if(response.has("error")||result==null||result.optBoolean("isError"))throw new IOException("备用网页阅读未返回公开正文");JSONArray blocks=result.optJSONArray("content");StringBuilder plain=new StringBuilder();if(blocks!=null)for(int i=0;i<blocks.length();i++){JSONObject block=blocks.getJSONObject(i);if(block.optString("type").equals("text"))plain.append(block.optString("text")).append('\n');}raw=plain.toString();reader="Exa网页阅读";
      }
      String title="网页",content,published="";
      if(raw.trim().startsWith("{")){JSONObject root=new JSONObject(raw),data=root.optJSONObject("data");if(data==null)throw new IOException("网页未返回正文");title=data.optString("title","网页");content=data.optString("content");published=data.optString("publishedTime");}
      else {content=raw;java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?m)^(?:Title: |# )(.+)$").matcher(raw);if(m.find())title=m.group(1);int p=raw.indexOf("Markdown Content:");if(p>=0)content=raw.substring(p+17);}
      if(challenge(raw)||content.trim().length()<40)throw new IOException("网站要求验证或没有公开正文，未读取成功");
      content=readerText(content);
      mark("web",true,"已通过"+reader+"读取公开正文");return new JSONObject().put("reader",reader).put("title",MainActivity.clean(title,180)).put("url",url).put("publisher",new URI(url).getHost()).put("published_at",stamp(published)).put("content",content.trim().substring(0,Math.min(content.trim().length(),6000))).put("truncated",content.trim().length()>=6000);
    }catch(Exception e){mark("web",false,app.friendly(e));throw e;}
  }
  JSONArray platform(JSONObject b,MainActivity.Job job)throws Exception {
    String id=b.optString("platform"),query=b.optString("query").trim();if(query.length()>300)throw new IOException("关键词过长");JSONArray out=new JSONArray();
    try{
      if(id.equals("github")){
        String repo=b.optString("repo"),url;if(!repo.isEmpty()){if(!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))throw new IOException("项目名称格式不正确");url="https://api.github.com/repos/"+repo;}else url="https://api.github.com/search/repositories?q="+URLEncoder.encode(query.isEmpty()?"artificial intelligence":query,"UTF-8")+"&sort=updated&per_page=6";
        JSONObject data=new JSONObject(fetch(url,null,job,false,"application/json"));JSONArray entries=repo.isEmpty()?data.optJSONArray("items"):new JSONArray().put(data);if(entries==null)throw new IOException("GitHub未返回项目");
        for(int n=0;n<Math.min(6,entries.length());n++){JSONObject e=entries.getJSONObject(n);out.put(new JSONObject().put("title",e.optString("full_name")).put("url",e.optString("html_url")).put("publisher","GitHub公开项目").put("published_at",stamp(e.optString("created_at"))).put("updated_at",stamp(e.optString("updated_at"))).put("snippet",MainActivity.clean(e.isNull("description")?"":e.optString("description"),350)).put("stars",e.optInt("stargazers_count")));}
      }else if(id.equals("v2ex")){
        JSONArray entries=new JSONArray(fetch("https://www.v2ex.com/api/topics/hot.json",null,job,false,"application/json"));for(int n=0;n<Math.min(6,entries.length());n++){JSONObject e=entries.getJSONObject(n);out.put(new JSONObject().put("title",e.optString("title")).put("url",e.optString("url").replaceFirst("^http:","https:")).put("publisher","V2EX社区讨论").put("published_at",java.time.Instant.ofEpochSecond(e.optLong("created")).toString()).put("snippet",MainActivity.clean(e.optString("content"),250)));}
      }else if(id.equals("bilibili")){
        JSONObject root=new JSONObject(fetch("https://api.bilibili.com/x/web-interface/search/all/v2?keyword="+URLEncoder.encode(query.isEmpty()?"人工智能":query,"UTF-8")+"&page=1",null,job,false,"application/json"));if(root.optInt("code",-1)!=0)throw new IOException("B站暂时限制公开搜索，请稍后再试");JSONArray groups=root.getJSONObject("data").getJSONArray("result");
        for(int i=0;i<groups.length();i++){JSONObject g=groups.getJSONObject(i);if(!g.optString("result_type").equals("video"))continue;JSONArray entries=g.getJSONArray("data");for(int n=0;n<Math.min(6,entries.length());n++){JSONObject e=entries.getJSONObject(n);String bv=e.optString("bvid");if(!bv.matches("BV[A-Za-z0-9]+"))continue;out.put(new JSONObject().put("title",MainActivity.clean(e.optString("title"),180)).put("url","https://www.bilibili.com/video/"+bv).put("publisher","B站视频").put("published_at",e.has("pubdate")?java.time.Instant.ofEpochSecond(e.optLong("pubdate")).toString():JSONObject.NULL).put("snippet",MainActivity.clean(e.optString("description"),250)));}}
      }else throw new IOException("该平台尚未接入公开读取");
      if(out.length()==0)throw new IOException("平台没有返回可用结果");mark(id,true,"取得"+out.length()+"条公开结果");return out;
    }catch(Exception e){mark(id,false,app.friendly(e));throw e;}
  }
  static JSONArray parseFeed(String raw,String base,String publisher)throws Exception {
    String upper=raw.toUpperCase(Locale.ROOT);if(upper.contains("<!DOCTYPE")||upper.contains("<!ENTITY"))throw new IOException("不读取含外部实体的订阅源");XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new StringReader(raw));JSONArray out=new JSONArray();Map<String,String> it=null;StringBuilder text=new StringBuilder();
    for(int event=p.getEventType();event!=XmlPullParser.END_DOCUMENT;event=p.next()){
      if(event==XmlPullParser.START_TAG){String tag=p.getName().replaceFirst("^.*:","");if(tag.equals("item")||tag.equals("entry"))it=new HashMap<>();if(it!=null&&tag.equals("link")){String href=p.getAttributeValue(null,"href"),rel=p.getAttributeValue(null,"rel");if(href!=null&&(rel==null||rel.equals("alternate")))it.put("link",href);}text.setLength(0);}
      else if(event==XmlPullParser.TEXT||event==XmlPullParser.CDSECT)text.append(p.getText());
      else if(event==XmlPullParser.END_TAG&&it!=null){String tag=p.getName().replaceFirst("^.*:","");if(tag.equals("item")||tag.equals("entry")){String url=it.getOrDefault("link",""),title=MainActivity.clean(it.getOrDefault("title",""),180);try{url=new URI(base).resolve(url).toString().replaceFirst("^http:","https:");publicUrl(url);if(!title.isEmpty())out.put(new JSONObject().put("title",title).put("url",url).put("publisher",publisher).put("snippet",MainActivity.clean(it.getOrDefault("description",it.getOrDefault("summary","")),250)).put("published_at",stamp(it.getOrDefault("pubDate",it.getOrDefault("published",it.getOrDefault("date",""))))).put("updated_at",stamp(it.getOrDefault("updated",""))));}catch(Exception ignored){}it=null;if(out.length()>=100)break;}else if(Arrays.asList("title","link","description","summary","pubDate","published","updated","date").contains(tag)){if(!tag.equals("link")||!text.toString().trim().isEmpty())it.put(tag,text.toString().trim());}text.setLength(0);}
    }return out;
  }
  JSONArray feed(JSONObject b,MainActivity.Job job)throws Exception {try{String url=publicUrl(b.optString("url"));JSONArray out=parseFeed(fetch(url,null,job,true,"application/rss+xml, application/atom+xml, text/xml"),url,b.optString("publisher",new URI(url).getHost()));if(out.length()==0)throw new IOException("订阅源没有可用条目");mark("rss",true,"已读取RSS/Atom公开来源");return out;}catch(Exception e){mark("rss",false,app.friendly(e));throw e;}}
  JSONObject probe(MainActivity.Job job)throws Exception {
    String[] ids={"search","web","github","bilibili","v2ex","rss"};for(String id:ids){if(job.cancelled)throw new IOException("已打断");try{
      if(id.equals("search"))search(new JSONObject().put("query","人工智能公开资讯"),job);
      if(id.equals("web"))read(new JSONObject().put("url","https://example.com"),job);
      if(id.equals("github"))platform(new JSONObject().put("platform",id).put("repo","Panniantong/Agent-Reach"),job);
      if(id.equals("bilibili")||id.equals("v2ex"))platform(new JSONObject().put("platform",id).put("query","人工智能"),job);
      if(id.equals("rss"))feed(new JSONObject().put("url","https://www.ithome.com/rss/").put("publisher","IT之家"),job);
    }catch(Exception e){if(job.cancelled)throw e;mark(id,false,app.friendly(e));}}
    return status();
  }
}
