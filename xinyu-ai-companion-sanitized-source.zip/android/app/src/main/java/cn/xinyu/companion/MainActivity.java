package cn.xinyu.companion;

import android.app.Activity;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.*;
import android.media.audiofx.*;
import android.os.*;
import android.speech.tts.*;
import android.security.keystore.*;
import android.util.Base64;
import android.view.*;
import android.webkit.*;
import android.net.Uri;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;
import org.xmlpull.v1.*;

/** Local UI only. No remote page can access the native bridge. */
public class MainActivity extends Activity {
  static final String ORIGIN="https://app.xinyu.invalid";
  WebView web;android.widget.FrameLayout container;
  boolean immersive=false;int safeLeft=0,safeTop=0,safeRight=0,safeBottom=0,imeBottom=0;
  void applyInsets(){
    if(container==null)return;container.setPadding(safeLeft,immersive?0:safeTop,safeRight,immersive?imeBottom:Math.max(safeBottom,imeBottom));
    float density=getResources().getDisplayMetrics().density;
    js("document.documentElement.style.setProperty('--native-safe-top','"+(immersive?safeTop/density:0)+"px');document.documentElement.style.setProperty('--native-safe-bottom','"+(immersive&&imeBottom==0?safeBottom/density:0)+"px')");
  }
  void applyScreenMode(boolean enabled){
    immersive=enabled;getWindow().setStatusBarColor(enabled?Color.TRANSPARENT:Color.rgb(248,244,243));getWindow().setNavigationBarColor(enabled?Color.TRANSPARENT:Color.rgb(248,244,243));
    getWindow().getDecorView().setSystemUiVisibility(enabled?View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    if(Build.VERSION.SDK_INT>=29){getWindow().setStatusBarContrastEnforced(false);getWindow().setNavigationBarContrastEnforced(!enabled);}applyInsets();container.requestApplyInsets();
  }
  final ExecutorService tasks=Executors.newFixedThreadPool(4), voiceWorker=Executors.newSingleThreadExecutor();
  final ConcurrentHashMap<String,Job> jobs=new ConcurrentHashMap<>();
  final Reach reach=new Reach(this);
  volatile long onlineMillis=0,onlineTick=0;volatile String onlineTimeSource="";
  volatile boolean foreground=true, speaking=false, modelReady=false;
  final SpeechGate speechGate=new SpeechGate();
  AudioManager audioManager;AudioDeviceCallback deviceCallback;
  volatile boolean headphones=false;volatile String voiceMode="speaker";
  boolean soloSpeech=false;
  JSONObject voicePolicy()throws JSONException{return new JSONObject().put("requested",voiceMode).put("effective",voiceMode.equals("headphones")&&headphones?"headphones":"speaker").put("available",headphones);}
  void refreshVoicePolicy(){
    boolean found=false;
    if(audioManager!=null)for(AudioDeviceInfo d:audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)){
      int t=d.getType();if(t==AudioDeviceInfo.TYPE_WIRED_HEADSET||t==AudioDeviceInfo.TYPE_WIRED_HEADPHONES||t==AudioDeviceInfo.TYPE_USB_HEADSET||t==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||t==AudioDeviceInfo.TYPE_BLUETOOTH_SCO||t==AudioDeviceInfo.TYPE_BLE_HEADSET||t==AudioDeviceInfo.TYPE_HEARING_AID)found=true;
    }
    headphones=found;speechGate.setSpeaker(!voiceMode.equals("headphones")||!headphones,SystemClock.elapsedRealtime());
    try{js("window.__nativeVoicePolicy?.("+voicePolicy().toString()+")");}catch(Exception ignored){}
  }
  volatile String spokenText="",micToken="";
  volatile AudioRecord recorder;volatile CaptureProcessor activeCapture;
  volatile ChineseSpeechEngine speechModel;
  TextToSpeech tts;
  volatile boolean ttsReady=false;
  String pendingMicId="",pendingMicToken="";int pendingSilence=1000;
  boolean askedMicPermission=false;
  String exportId, exportText;
  final Bridge bridge=new Bridge();
  static class Job {volatile boolean cancelled; volatile HttpURLConnection conn; volatile Future<?> future;}
  @Override public void onCreate(Bundle state){
    super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(248,244,243));getWindow().setNavigationBarColor(Color.rgb(248,244,243));
    web=new WebView(this);web.setBackgroundColor(Color.rgb(248,244,243));
    container=new android.widget.FrameLayout(this);
    container.addView(web,new android.widget.FrameLayout.LayoutParams(-1,-1));
    container.setOnApplyWindowInsetsListener((v,insets)->{
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()),ime=insets.getInsets(WindowInsets.Type.ime());safeLeft=bars.left;safeTop=bars.top;safeRight=bars.right;safeBottom=bars.bottom;imeBottom=ime.bottom;}
      else{safeLeft=insets.getSystemWindowInsetLeft();safeTop=insets.getSystemWindowInsetTop();safeRight=insets.getSystemWindowInsetRight();int bottom=insets.getSystemWindowInsetBottom();imeBottom=bottom>getResources().getDisplayMetrics().heightPixels*.18?bottom:0;if(imeBottom==0)safeBottom=bottom;}
      applyInsets();
      return insets.consumeSystemWindowInsets();
    });
    setContentView(container);
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setMediaPlaybackRequiresUserGesture(false);s.setSupportMultipleWindows(false);
    web.addJavascriptInterface(bridge,"XinyuNative");
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onJsConfirm(WebView w,String u,String text,JsResult result){new android.app.AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("确定",(d,i)->result.confirm()).setNegativeButton("取消",(d,i)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
    });
    web.setWebViewClient(new WebViewClient(){
      @Override public void onPageFinished(WebView view,String url){applyInsets();}
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
        Uri uri=req.getUrl();if(!ORIGIN.equals(uri.getScheme()+"://"+uri.getAuthority()))return blocked();
        String p=uri.getPath();if(p==null||p.equals("/"))p="/index.html";
        if(p.contains("..")||p.contains("\\"))return blocked();
        try{
          String ext=p.substring(p.lastIndexOf('.')+1);String mime=ext.equals("js")?"application/javascript":ext.equals("css")?"text/css":ext.equals("html")?"text/html":ext.equals("jpg")?"image/jpeg":ext.equals("png")?"image/png":ext.equals("mp4")?"video/mp4":"application/octet-stream";
          return new WebResourceResponse(mime,"UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-cache"),getAssets().open("web"+p));
        }catch(Exception e){return blocked();}
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
        Uri u=req.getUrl();if(u.toString().startsWith(ORIGIN+"/"))return false;
        if(req.isForMainFrame()&&publicLink(u.toString()))try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
        return true;
      }
    });
    audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
    voiceMode=getSharedPreferences("voice",MODE_PRIVATE).getString("mode","speaker");
    deviceCallback=new AudioDeviceCallback(){public void onAudioDevicesAdded(AudioDeviceInfo[] d){refreshVoicePolicy();}public void onAudioDevicesRemoved(AudioDeviceInfo[] d){refreshVoicePolicy();}};
    audioManager.registerAudioDeviceCallback(deviceCallback,new Handler(Looper.getMainLooper()));refreshVoicePolicy();
    tts=new TextToSpeech(this,status->{ttsReady=status==TextToSpeech.SUCCESS; if(ttsReady){int r=tts.setLanguage(Locale.SIMPLIFIED_CHINESE);ttsReady=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;}});
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
      public void onStart(String id){runOnUiThread(()->{if(!id.equals(currentSpeechId))return;speaking=true;js("window.__nativeSpeech?.('start')");});}
      public void onDone(String id){completeSpeech(id,true);}
      public void onError(String id){completeSpeech(id,false);}
      public void onStop(String id,boolean interrupted){completeSpeech(id,false);}
    });
    web.loadUrl(ORIGIN+"/");
  }
  WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  void js(String script){runOnUiThread(()->{if(web!=null&&!isFinishing())web.evaluateJavascript(script,null);});}
  static String jsonValue(Object value){String array=new JSONArray().put(value).toString();return array.substring(1,array.length()-1);}
  void reply(String id,Object value,String error){jobs.remove(id);js("window.__nativeReply?.("+JSONObject.quote(id)+","+(value==null?"null":jsonValue(value))+","+(error==null?"null":JSONObject.quote(error))+")");}
  void micEvent(String token,String type,Object data){
    final long revision=speechGate.revision();
    runOnUiThread(()->{if(!token.equals(micToken)||!foreground||web==null)return;
      if((type.equals("start")||type.equals("text"))&&speechGate.discard(revision,SystemClock.elapsedRealtime()))return;
      web.evaluateJavascript("window.__nativeMic?.("+JSONObject.quote(token)+","+JSONObject.quote(type)+","+jsonValue(data)+")",null);
    });
  }
  void completeSpeech(String id,boolean ok){runOnUiThread(()->{
    if(id.equals(currentSpeechId)){speechGate.finishChunk(id,SystemClock.elapsedRealtime());if(soloSpeech)speechGate.stop(SystemClock.elapsedRealtime());speaking=false;spokenText="";currentSpeechId="";soloSpeech=false;js("window.__nativeSpeech?.('stop')");}
    if(jobs.containsKey(id))reply(id,new JSONObject(Collections.singletonMap("ok",ok)),null);
  });}
  void stopSpeech(){stopSpeech(false);}
  void stopSpeech(boolean fromVoice){
    if(fromVoice)speechGate.voiceInterrupt(SystemClock.elapsedRealtime());else speechGate.stop(SystemClock.elapsedRealtime());String id=currentSpeechId;currentSpeechId="";soloSpeech=false;if(tts!=null)tts.stop();speaking=false;spokenText="";js("window.__nativeSpeech?.('stop')");
    if(!id.isEmpty()&&jobs.containsKey(id))reply(id,new JSONObject(Collections.singletonMap("ok",false)),null);
  }
  void haltMic(){micToken="";AudioRecord r=recorder;if(r!=null)try{r.stop();}catch(Exception ignored){} }
  @Override protected void onPause(){foreground=false;js("window.dispatchEvent(new Event('xinyu-native-pause'));document.querySelectorAll('video').forEach(v=>v.pause())");haltMic();stopSpeech();for(Job j:jobs.values()){j.cancelled=true;if(j.conn!=null)j.conn.disconnect();}if(web!=null)web.onPause();super.onPause();}
  @Override protected void onResume(){super.onResume();foreground=true;if(web!=null)web.onResume();js("window.dispatchEvent(new Event('xinyu-native-resume'))");}
  @Override protected void onDestroy(){if(audioManager!=null&&deviceCallback!=null)audioManager.unregisterAudioDeviceCallback(deviceCallback);haltMic();stopSpeech();if(tts!=null)tts.shutdown();tasks.shutdownNow();voiceWorker.submit(()->{ChineseSpeechEngine m=speechModel;speechModel=null;modelReady=false;if(m!=null)m.close();});voiceWorker.shutdown();WebView w=web;web=null;if(w!=null){w.removeJavascriptInterface("XinyuNative");w.destroy();}super.onDestroy();}
  @Override public void onBackPressed(){js("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))");new android.app.AlertDialog.Builder(this).setMessage("返回桌面？心屿会暂停麦克风。") .setPositiveButton("返回桌面",(d,i)->moveTaskToBack(true)).setNegativeButton("继续陪伴",null).show();}
  class Bridge {
    @JavascriptInterface public void call(String id,String method,String raw){
      if(id==null||id.length()>30)return;Job job=new Job();jobs.put(id,job);
      // Playback controls preserve bridge call order. A delayed worker must not
      // reopen an old capture exclusion after the user has already stopped it.
      if(method.equals("speechBegin")||method.equals("speechEnd")||method.equals("speak")){
        try{JSONObject body=new JSONObject(raw);runOnUiThread(()->{
          if(job.cancelled||!foreground){reply(id,null,"已停止播放");return;}
          if(method.equals("speechBegin")){stopSpeech();speechGate.begin(body.optString("session"));reply(id,new JSONObject(Collections.singletonMap("ok",true)),null);}
          else if(method.equals("speechEnd")){speechGate.end(body.optString("session"),SystemClock.elapsedRealtime());reply(id,new JSONObject(Collections.singletonMap("ok",true)),null);}
          else speak(id,body,job);
        });}catch(Exception e){reply(id,null,friendly(e));}return;
      }
      job.future=tasks.submit(()->{try{
        if(job.cancelled)return;
        JSONObject body=new JSONObject(raw);Object result;
        switch(method){
          case "connection":result=connection();break;
          case "saveConnection":result=saveConnection(body);break;
          case "model":result=model(body,job);break;
          case "get":result=get(body.getString("url"),job,false);break;
          case "rss":result=rss(body,job);break;
          case "newsSearch":result=newsSearch(body,job);break;
          case "clock":result=clock(job);break;
          case "reachStatus":result=reach.status();break;
          case "reachProbe":result=reach.probe(job);break;
          case "reachSearch":result=reach.search(body,job);break;
          case "reachRead":result=reach.read(body,job);break;
          case "reachPlatform":result=reach.platform(body,job);break;
          case "reachFeed":result=reach.feed(body,job);break;
          case "diagnostics":result=new JSONObject().put("model_configured",connection().getBoolean("configured")).put("speech",new JSONObject().put("ready",modelReady).put("loading",!modelReady).put("model","SenseVoice中文增强 · Silero语音检测").put("device","手机CPU").put("engine","offline")).put("tts_ready",ttsReady);break;
          case "immersive":runOnUiThread(()->{applyScreenMode(body.optBoolean("enabled"));reply(id,new JSONObject(Collections.singletonMap("ok",true)),null);});return;
          case "voiceMode":runOnUiThread(()->{try{if(body.has("mode")){String mode=body.getString("mode");if(!mode.equals("speaker")&&!mode.equals("headphones"))throw new IOException("请选择外放或耳机模式");voiceMode=mode;getSharedPreferences("voice",MODE_PRIVATE).edit().putString("mode",mode).apply();}refreshVoicePolicy();reply(id,voicePolicy(),null);}catch(Exception e){reply(id,null,friendly(e));}});return;
          case "micStart":startMic(id,body,job);return;
          case "export":runOnUiThread(()->export(id,body));return;
          case "copy":runOnUiThread(()->((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("心屿",body.optString("text"))));result=new JSONObject().put("ok",true);break;
          default:throw new IOException("手机端未支持此功能");
        }
        if(!job.cancelled)reply(id,result,null);else reply(id,null,"已打断");
      }catch(Exception e){reply(id,null,friendly(e));}});
    }
    @JavascriptInterface public void cancel(String id){Job j=jobs.remove(id);if(j!=null){j.cancelled=true;if(j.conn!=null)j.conn.disconnect();if(j.future!=null)j.future.cancel(true);}runOnUiThread(()->{if(id.equals(currentSpeechId))stopSpeech();});}
    @JavascriptInterface public void stopSpeech(){runOnUiThread(()->MainActivity.this.stopSpeech());}
    @JavascriptInterface public void stopMic(String token){if(token.equals(micToken)||token.equals(pendingMicToken)){pendingMicToken="";haltMic();}}
  }
  String friendly(Exception e){
    if(e instanceof SocketTimeoutException)return "网络超时，请稍后重试";
    if(e instanceof UnknownHostException)return "无法连接服务，请检查手机网络和服务地址";
    if(e instanceof javax.net.ssl.SSLException)return "安全连接失败，请检查服务HTTPS证书和手机日期";
    if(e instanceof IOException&&e.getMessage()!=null&&e.getMessage().length()<120)return e.getMessage();
    return "操作未完成，请检查设置后重试";
  }
  JSONObject connection() throws Exception {android.content.SharedPreferences p=getSharedPreferences("connection",MODE_PRIVATE);return new JSONObject().put("base_url",p.getString("url","https://api.deepseek.com/v1")).put("model",p.getString("model","deepseek-chat")).put("configured",!p.getString("secret","").isEmpty());}
  SecretKey cipherKey() throws Exception {
    KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
    if(!ks.containsAlias("xinyu-model-key")){KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");gen.init(new KeyGenParameterSpec.Builder("xinyu-model-key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());gen.generateKey();}
    return (SecretKey)ks.getKey("xinyu-model-key",null);
  }
  JSONObject saveConnection(JSONObject body) throws Exception {
    String url=body.optString("base_url").trim().replaceAll("/+$", ""), model=body.optString("model").trim(),secret=body.optString("key").trim();
    URI uri=new URI(url);if(!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null)throw new IOException("模型地址请填写HTTPS服务地址，不要附带密钥");
    if(model.isEmpty()||model.length()>100||secret.length()>4096)throw new IOException("请检查模型名称和密钥长度");
    android.content.SharedPreferences.Editor ed=getSharedPreferences("connection",MODE_PRIVATE).edit().putString("url",url).putString("model",model);
    if(!secret.isEmpty()){Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,cipherKey());ed.putString("secret",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(secret.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP));}
    if(!ed.commit())throw new IOException("连接设置未能保存");return connection();
  }
  String secret()throws Exception {
    String saved=getSharedPreferences("connection",MODE_PRIVATE).getString("secret","");if(saved.isEmpty())throw new IOException("请先到连接设置填写模型密钥");String[] parts=saved.split(":");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,cipherKey(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
  }
  String model(JSONObject body,Job job)throws Exception {
    if(job.cancelled)throw new IOException("已打断");
    JSONObject cfg=connection();String url=cfg.getString("base_url")+"/chat/completions";
    JSONObject req=new JSONObject().put("model",cfg.getString("model")).put("messages",body.getJSONArray("messages")).put("temperature",body.optDouble("temperature",.75)).put("max_tokens",body.optInt("max_tokens",600)).put("stream",false);
    HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();job.conn=conn;
    try{
      conn.setConnectTimeout(10000);conn.setReadTimeout(60000);conn.setInstanceFollowRedirects(false);conn.setRequestMethod("POST");conn.setRequestProperty("Content-Type","application/json");conn.setRequestProperty("Authorization","Bearer "+secret());conn.setDoOutput(true);
      try(OutputStream out=conn.getOutputStream()){out.write(req.toString().getBytes(StandardCharsets.UTF_8));}
      int status=conn.getResponseCode();
      if(status==401||status==403)throw new IOException("模型密钥无效或权限不足，请检查连接");if(status==429)throw new IOException("模型服务额度或频率受限，请稍后重试");if(status==404)throw new IOException("模型名称或服务地址不正确，请检查连接");if(status<200||status>=300)throw new IOException("模型服务返回HTTP "+status+"，请检查连接");
      String raw=read(conn.getInputStream(),job,3000000);JSONObject json=new JSONObject(raw);String text=json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").trim();if(text.isEmpty()||text.length()>20000)throw new IOException("模型没有返回可用文字");return text;
    }finally{job.conn=null;conn.disconnect();}
  }
  static boolean publicLink(String text){try{URI u=new URI(text);String h=u.getHost();return ("https".equals(u.getScheme())||"http".equals(u.getScheme()))&&h!=null&&h.contains(".")&&u.getUserInfo()==null&&!h.equals("localhost")&&!h.matches("[0-9.]+")&&!h.contains(":");}catch(Exception e){return false;}}
  static boolean provider(String text){try{URI u=new URI(text);if(!"https".equals(u.getScheme())||u.getUserInfo()!=null||u.getPort()!=-1)return false;String h=u.getHost(),p=u.getPath();return ("www.chinanews.com.cn".equals(h)&&p.matches("/rss/(china|society|finance|world|scroll-news|importnews|culture|sports)\\.xml"))||("sou.chinanews.com.cn".equals(h)&&p.equals("/search.do"))||("news.google.com".equals(h)&&p.equals("/rss/search"))||("www.bing.com".equals(h)&&p.equals("/search"))||("geocoding-api.open-meteo.com".equals(h)&&p.equals("/v1/search"))||("api.open-meteo.com".equals(h)&&p.equals("/v1/forecast"))||("data.weather.gov.hk".equals(h)&&p.equals("/weatherAPI/opendata/lunardate.php"));}catch(Exception e){return false;}}
  String get(String url,Job job,boolean unused)throws Exception {
    if(job.cancelled)throw new IOException("已打断");
    if(!provider(url))throw new IOException("此查询地址不受支持");HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();job.conn=conn;
    try{conn.setConnectTimeout(7000);conn.setReadTimeout(12000);conn.setInstanceFollowRedirects(false);conn.setUseCaches(false);conn.setRequestProperty("Cache-Control","no-cache");conn.setRequestProperty("User-Agent","XinyuPersonalAndroid/1.3.2");int status=conn.getResponseCode();if(status!=200)throw new IOException("来源暂时不可达（HTTP "+status+"）");long stamp=conn.getHeaderFieldDate("Date",0);if(stamp>0){onlineMillis=stamp;onlineTick=SystemClock.elapsedRealtime();onlineTimeSource=new URI(url).getHost();}return read(conn.getInputStream(),job,2000000);}finally{job.conn=null;conn.disconnect();}
  }
  JSONObject clock(Job job)throws Exception {
    if(onlineMillis==0||SystemClock.elapsedRealtime()-onlineTick>300000){try{get("https://www.chinanews.com.cn/rss/importnews.xml",job,false);}catch(Exception e){if(job.cancelled)throw e;}}
    boolean verified=onlineMillis>0&&SystemClock.elapsedRealtime()-onlineTick<=300000;long now=verified?onlineMillis+SystemClock.elapsedRealtime()-onlineTick:System.currentTimeMillis();
    return new JSONObject().put("now_ms",now).put("verified",verified).put("source",verified?onlineTimeSource:"手机系统时间").put("device_skew_ms",now-System.currentTimeMillis());
  }
  static JSONArray parseSearch(String raw)throws Exception {
    java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\bvar\\s+docArr\\s*=\\s*(\\[.*?\\])\\s*;",java.util.regex.Pattern.DOTALL).matcher(raw);
    if(!m.find())throw new IOException("新闻搜索页面结构变化，已切换其他来源");JSONArray docs=new JSONArray(m.group(1)),items=new JSONArray();
    for(int n=0;n<Math.min(30,docs.length());n++){JSONObject doc=docs.getJSONObject(n);String url=doc.optString("url"),title;Object t=doc.opt("title");if(t instanceof JSONArray){JSONArray a=(JSONArray)t;StringBuilder b=new StringBuilder();for(int k=0;k<a.length();k++)b.append(a.optString(k));title=clean(b.toString(),180);}else title=clean(doc.optString("title"),180);
      if(!publicLink(url)||title.isEmpty())continue;URI u=new URI(url);String host=u.getHost();if(!host.equals("www.chinanews.com.cn")&&!host.endsWith(".chinanews.com.cn"))continue;url=url.replaceFirst("^http:","https:");
      Object stamp=JSONObject.NULL;try{stamp=java.time.LocalDateTime.parse(doc.optString("pubtime"),java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).toInstant(java.time.ZoneOffset.ofHours(8)).toString();}catch(Exception ignored){}
      items.put(new JSONObject().put("title",title).put("url",url).put("publisher","中国新闻网·关键词搜索").put("published_at",stamp).put("snippet",clean(doc.optString("content_without_tag"),180)));
    }return items;
  }
  JSONArray newsSearch(JSONObject body,Job job)throws Exception {
    String q=body.optString("query").trim(),channel=body.optString("channel","all");if(q.length()>60||!Arrays.asList("all","gj","gn","cj").contains(channel))throw new IOException("新闻关键词或栏目不正确");
    return parseSearch(get("https://sou.chinanews.com.cn/search.do?q="+URLEncoder.encode(q,"UTF-8")+"&sortType=time&searchField=title&channel="+channel,job,false));
  }
  String read(InputStream input,Job job,int cap)throws Exception {try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(job.cancelled)throw new IOException("已打断");if(out.size()+n>cap)throw new IOException("服务响应过大");out.write(b,0,n);}return out.toString("UTF-8");}}
  JSONArray rss(JSONObject body,Job job)throws Exception {
    String raw=get(body.getString("url"),job,false);if(raw.toUpperCase(Locale.ROOT).contains("<!DOCTYPE")||raw.toUpperCase(Locale.ROOT).contains("<!ENTITY"))throw new IOException("来源格式不安全");
    XmlPullParserFactory factory=XmlPullParserFactory.newInstance();factory.setNamespaceAware(false);XmlPullParser parser=factory.newPullParser();parser.setInput(new StringReader(raw));
    JSONArray results=new JSONArray();Map<String,String> it=null;String tag="";StringBuilder value=new StringBuilder();
    for(int e=parser.getEventType();e!=XmlPullParser.END_DOCUMENT;e=parser.next()){
      if(e==XmlPullParser.START_TAG){tag=parser.getName();if(tag.equals("item"))it=new HashMap<>();if(tag.equals("source")&&it!=null)it.put("source_url",parser.getAttributeValue(null,"url"));value.setLength(0);}
      else if(e==XmlPullParser.TEXT||e==XmlPullParser.CDSECT)value.append(parser.getText());
      else if(e==XmlPullParser.END_TAG&&it!=null){String end=parser.getName();if(end.equals("item")){
          String link=it.getOrDefault("link",""),title=clean(it.getOrDefault("title",""),180);if(publicLink(link)&&!title.isEmpty()){
            String pub=body.optString("publisher");boolean agg=body.optBoolean("aggregator");if(agg)pub=it.containsKey("source")?it.get("source"):title.contains(" - ")?title.substring(title.lastIndexOf(" - ")+3):pub;
            JSONObject obj=new JSONObject().put("title",title).put("url",link).put("publisher",pub).put("snippet",clean(it.getOrDefault("description",""),180)).put("published_at",date(it.getOrDefault("pubDate","")));if(agg)obj.put("aggregator",true).put("source_url",it.get("source_url"));results.put(obj);}
          it=null;if(results.length()>=100)break;
        }else if(Arrays.asList("title","link","description","pubDate","source").contains(end))it.put(end,value.toString().trim());value.setLength(0);
      }
    }return results;
  }
  static String clean(String s,int max){s=s.replaceAll("<[^>]*>","").replace("&amp;","&").replace("&quot;","\"").replace("&nbsp;"," ").replace("&lt;","<").replace("&gt;",">").trim();return s.substring(0,Math.min(s.length(),max));}
  static Object date(String raw){try{java.time.ZonedDateTime date=java.time.ZonedDateTime.parse(raw,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME);return date.toInstant().toString();}catch(Exception e){return JSONObject.NULL;}}
  volatile String currentSpeechId="";
  void speak(String id,JSONObject body,Job job){
    if(job.cancelled||!foreground){reply(id,new JSONObject(Collections.singletonMap("ok",false)),null);return;}
    if(!ttsReady){reply(id,null,"手机没有可用的中文语音引擎，请在系统的文字转语音设置中安装或启用中文声音");return;}
    String text=body.optString("text");if(text.isEmpty()||text.length()>300){reply(id,null,"朗读内容为空或过长");return;}
    String session=body.optString("session");
    if(session.isEmpty()){stopSpeech();session="solo-"+id;speechGate.begin(session);soloSpeech=true;}
    else if(!speechGate.owns(session)){reply(id,new JSONObject(Collections.singletonMap("ok",false)),null);return;}
    String old=currentSpeechId;currentSpeechId="";if(!old.isEmpty()){tts.stop();speechGate.finishChunk(old,SystemClock.elapsedRealtime());if(jobs.containsKey(old))reply(old,new JSONObject(Collections.singletonMap("ok",false)),null);}
    speechGate.chunk(session,id);currentSpeechId=id;speaking=true;spokenText=text;try{float rate=1+Float.parseFloat(body.optString("rate","+0%").replace("%",""))/100f;tts.setSpeechRate(Math.max(.6f,Math.min(1.5f,rate)));}catch(Exception ignored){}
    if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,id)==TextToSpeech.ERROR)completeSpeech(id,false);
  }
  void export(String id,JSONObject body){
    if(exportId!=null){reply(id,null,"请先完成上一次保存");return;}
    exportId=id;exportText=body.optString("text");Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.setType("application/json");intent.addCategory(Intent.CATEGORY_OPENABLE);intent.putExtra(Intent.EXTRA_TITLE,body.optString("filename","心屿-记录.json"));try{startActivityForResult(intent,12);}catch(Exception e){exportId=null;exportText=null;reply(id,null,"手机暂时无法选择保存位置");}
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==12&&exportId!=null){String id=exportId,text=exportText;exportId=null;exportText=null;if(result!=RESULT_OK||data==null){reply(id,null,"已取消保存");return;}tasks.submit(()->{try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(text.getBytes(StandardCharsets.UTF_8));reply(id,new JSONObject().put("ok",true),null);}catch(Exception e){reply(id,null,"记录未能保存，请重试");}});}}
  void loadModel()throws Exception{
    if(speechModel!=null)return;
    synchronized(this){if(speechModel!=null)return;File dir=new File(getFilesDir(),"speech-sensevoice-20240717");File marker=new File(dir,"ready");if(!marker.exists()){copyAsset("speech-hq",dir);try(FileOutputStream out=new FileOutputStream(marker)){out.write(1);}}
      speechModel=new ChineseSpeechEngine(dir.getAbsolutePath());modelReady=true;}
  }
  void copyAsset(String asset,File dest)throws IOException{String[] children=getAssets().list(asset);if(children!=null&&children.length>0){if(!dest.exists()&&!dest.mkdirs())throw new IOException("语音模型目录未能创建");for(String c:children)copyAsset(asset+"/"+c,new File(dest,c));}else{try(InputStream in=getAssets().open(asset);OutputStream out=new FileOutputStream(dest)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);}}}
  void startMic(String id,JSONObject body,Job job)throws Exception{
    String token=body.getString("token");pendingMicToken=token;pendingMicId=id;pendingSilence=Math.max(700,Math.min(2000,body.optInt("silenceMs",1000)));
    loadModel();if(job.cancelled||!foreground||!token.equals(pendingMicToken)){reply(id,null,"已暂停麦克风");return;}
    runOnUiThread(()->{if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){if(askedMicPermission){reply(id,null,"麦克风权限未开启，请在手机设置中允许心屿使用麦克风；也可以继续打字聊天");return;}askedMicPermission=true;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},11);}else beginMic(id,token,pendingSilence);});
  }
  @Override public void onRequestPermissionsResult(int request,String[] perms,int[] grants){super.onRequestPermissionsResult(request,perms,grants);if(request==11){String id=pendingMicId,token=pendingMicToken;if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED&&!token.isEmpty())beginMic(id,token,pendingSilence);else reply(id,null,"麦克风权限未开启，请在手机设置中允许心屿使用麦克风；也可以继续打字聊天");}}
  void beginMic(String id,String token,int silence){
    haltMic();if(!foreground||token.isEmpty()||!token.equals(pendingMicToken)){reply(id,null,"已暂停麦克风");return;}micToken=token;
    voiceWorker.submit(()->audioLoop(id,token,silence));
  }
  void audioLoop(String id,String token,int silence){
    AudioRecord audio=null;CaptureProcessor processor=null;AcousticEchoCanceler aec=null;NoiseSuppressor ns=null;
    try{
      if(!token.equals(micToken)||!foreground){reply(id,null,"已暂停麦克风");return;}
      int buffer=Math.max(4096,AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT));
      audio=new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,buffer*2);
      if(audio.getState()!=AudioRecord.STATE_INITIALIZED)throw new IOException("手机麦克风未能启动，请检查权限或其他通话应用");
      recorder=audio;if(AcousticEchoCanceler.isAvailable()){aec=AcousticEchoCanceler.create(audio.getAudioSessionId());if(aec!=null)aec.setEnabled(true);}
      processor=new CaptureProcessor(speechModel,speechGate,silence,()->speaking,()->spokenText,(type,value)->{
        if(type.equals("start"))runOnUiThread(()->{if(!token.equals(micToken)||!foreground||speechGate.blocks(SystemClock.elapsedRealtime()))return;stopSpeech(true);micEvent(token,type,value);});
        else micEvent(token,type,value);
      });
      activeCapture=processor;audio.startRecording();reply(id,new JSONObject().put("ok",true),null);
      short[] pcm=new short[1600];
      while(foreground&&token.equals(micToken)){
        long frameRevision=speechGate.revision();int n=audio.read(pcm,0,pcm.length);
        if(n<0)throw new IOException("麦克风被占用或断开，请重试");if(n==0)continue;
        processor.feed(pcm,n,frameRevision,SystemClock.elapsedRealtime());
      }
    }catch(Exception e){reply(id,null,friendly(e));micEvent(token,"error",friendly(e));}
    finally{if(audio!=null){try{audio.stop();}catch(Exception ignored){}audio.release();}if(recorder==audio)recorder=null;if(aec!=null)aec.release();if(ns!=null)ns.release();if(processor!=null)processor.close();if(activeCapture==processor)activeCapture=null;}
  }
  static boolean isEcho(String heard,String spoken){String h=heard.replaceAll("[\\p{Punct}，。！？ ]", ""),s=spoken.replaceAll("[\\p{Punct}，。！？ ]", "");if(h.isEmpty())return true;return h.length()>=2&&(s.contains(h)||h.contains(s)&&s.length()>3);}
  static boolean isPathological(String text){return text.length()>1800||text.matches("(.{2,12})\\1{5,}.*");}
}
