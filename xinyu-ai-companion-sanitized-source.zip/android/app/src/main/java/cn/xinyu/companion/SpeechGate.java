package cn.xinyu.companion;

/** Capture exclusion owned by a whole playback session, not TTS callbacks alone. */
final class SpeechGate {
  static final long TAIL_MS=1200;
  private String session="",chunk="";
  private boolean speaker=true;
  private long tailUntil=0,revision=0;
  synchronized void setSpeaker(boolean value,long now){
    if(speaker!=value){speaker=value;tailUntil=Math.max(tailUntil,now+TAIL_MS);revision++;}
  }
  synchronized void begin(String owner){session=owner;chunk="";if(speaker)revision++;}
  synchronized boolean owns(String owner){return !owner.isEmpty()&&owner.equals(session);}
  synchronized boolean chunk(String owner,String id){if(!owns(owner))return false;chunk=id;if(speaker)revision++;return true;}
  synchronized boolean finishChunk(String id,long now){
    if(!id.equals(chunk)||id.isEmpty())return false;
    chunk="";if(speaker){tailUntil=Math.max(tailUntil,now+TAIL_MS);revision++;}return true;
  }
  synchronized boolean end(String owner,long now){if(!owns(owner))return false;stop(now);return true;}
  synchronized void stop(long now){
    if(speaker&&(!session.isEmpty()||!chunk.isEmpty())){tailUntil=Math.max(tailUntil,now+TAIL_MS);revision++;}
    session="";chunk="";
  }
  // Accepted headphone speech must survive stopping TTS. A new exclusion here
  // would discard the very utterance that interrupted playback.
  synchronized void voiceInterrupt(long now){
    if(speaker){stop(now);return;}
    session="";chunk="";tailUntil=0;
  }
  synchronized boolean blocks(long now){return now<tailUntil||(speaker&&(!session.isEmpty()||!chunk.isEmpty()));}
  synchronized long revision(){return revision;}
  synchronized boolean discard(long frameRevision,long now){return revision!=frameRevision||blocks(now);}
}
