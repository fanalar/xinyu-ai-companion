import {native} from './native.js'
const key='xinyu-reach-settings-v1'
const defaults={expanded_news:true,public_search:true,page_reader:true,community:true}
export function reachSettings(){try{return {...defaults,...JSON.parse(localStorage.getItem(key)||'{}')}}catch{return {...defaults}}}
export function saveReachSettings(body){const s=reachSettings();for(const k of Object.keys(defaults))if(typeof body[k]==='boolean')s[k]=body[k];localStorage.setItem(key,JSON.stringify(s));return s}
export const linkOf=text=>text.match(/https?:\/\/[^\s<>"“”]+/)?.[0]?.replace(/[，。！？；）》）]+$/,'')||''
export function reachIntent(text){
  if(/不(要|用|想|需要)(联网|上网|查|搜索|新闻|资讯)|别读|不要读/.test(text))return ''
  if(linkOf(text))return /RSS|Atom|订阅源|\.xml(?:[？?]|$)|\/feed(?:[？?]|$)/i.test(text)?'feed':'read'
  if(/github|开源项目|开源仓库/i.test(text))return 'github'
  if(/B站|哔哩哔哩|bilibili/i.test(text)&&/搜|查|找|视频|教程/.test(text))return 'bilibili'
  if(/V2EX/i.test(text))return 'v2ex'
  return ''
}
export const searchQuery=text=>text.replace(/^(?:你能|你可以|能否|能不能|可不可以|麻烦|请|帮我|给我|我想|联网|上网|搜索|搜一下|查一下|查查|查一查|查询)+/,'').replace(/[？?。！!]$/,'').trim().slice(0,500)
export async function expandedNews(text,topic,signal){
  if(!reachSettings().expanded_news)return {items:[],checks:[]}
  const international=/国内外|国外|国际|海外|世界|全球/.test(text),tech=/人工智能|科技|汽车|半导体|机器人/.test(topic)
  const sources=[]
  if(tech||!topic&&!/国内|中国/.test(text))sources.push({url:'https://www.ithome.com/rss/',publisher:'IT之家'})
  if(international||!topic&&!/国内|中国/.test(text))sources.push({url:'https://www.rfi.fr/cn/rss',publisher:'RFI中文'},{url:'https://feeds.bbci.co.uk/zhongwen/simp/rss.xml',publisher:'BBC中文'})
  const jobs=await Promise.allSettled(sources.map(s=>native('reachFeed',s,signal)))
  if(signal?.aborted)throw new DOMException('已打断','AbortError')
  return {items:jobs.flatMap(r=>r.status==='fulfilled'&&Array.isArray(r.value)?r.value:[]),checks:sources.map((s,i)=>({source:s.publisher,status:jobs[i].status==='fulfilled'?'connected':'unreachable',count:jobs[i].status==='fulfilled'&&Array.isArray(jobs[i].value)?jobs[i].value.length:0}))}
}
function listReply(items,label,note){return {kind:'reach',status:'ok',checked_at:new Date().toISOString(),sources:items,backend:label,reply:label+'\n'+note+'\n\n'+items.slice(0,6).map((s,i)=>`${i+1}、${s.title}\n${s.snippet||''}${s.published_at?'\n发布：'+new Date(s.published_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}):'\n发布时间未核实'}${s.updated_at?' · 更新：'+new Date(s.updated_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}):''}`).join('\n\n')}}
export async function reachRead(text,intent,signal){
  const settings=reachSettings()
  if((intent==='read'||intent==='feed')&&!settings.page_reader)return {kind:'reach',status:'clarification',sources:[],reply:'公开网页阅读已关闭，可在设置→联网资讯中开启。'}
  if(['github','bilibili','v2ex'].includes(intent)&&!settings.community)return {kind:'reach',status:'clarification',sources:[],reply:'公开社区和视频查询已关闭，可在设置→联网资讯中开启。'}
  if(intent==='read'){
    const url=linkOf(text),s=await native('reachRead',{url},signal)
    return {kind:'reach',status:'ok',backend:s.reader||'Jina Reader',checked_at:new Date().toISOString(),sources:[{title:s.title,url:s.url,publisher:s.publisher,published_at:s.published_at}],reply:`${s.title}\n公开网页内容摘录${s.truncated?'（长文只展示前一部分）':''}；页面日期${s.published_at?'：'+s.published_at:'未核实'}。\n\n${s.content}`}
  }
  if(intent==='feed')return listReply(await native('reachFeed',{url:linkOf(text)},signal),'公开订阅源','按源提供的时间列出条目，更新日期不等于首次发布时间。')
  const query=searchQuery(text.replace(/B站|哔哩哔哩|bilibili|github|V2EX/gi,''))
  const items=await native('reachPlatform',{platform:intent,query},signal)
  return listReply(items,{github:'GitHub公开项目',bilibili:'B站视频搜索',v2ex:'V2EX热门讨论'}[intent],intent==='v2ex'?'这是社区热门讨论，代表发帖者观点，不当作新闻事实；当前不是全站关键词搜索。':intent==='github'?'项目创建和更新日期分别标注，不当作新闻发布日期。':'这里只读取公开视频标题、简介和链接，没有读取字幕，也不声称看过视频。')
}
export async function publicSearch(text,signal){
  if(!reachSettings().public_search)return {kind:'search',status:'clarification',sources:[],reply:'广泛搜索已关闭，可在设置→联网资讯中开启。'}
  const q=searchQuery(text);if(!q)return {kind:'search',status:'clarification',sources:[],reply:'你想查什么？请补充关键词。'}
  let items,backend='Exa公开搜索',fallback=false
  try{items=await native('reachSearch',{query:q},signal)}catch(e){if(signal?.aborted)throw e;fallback=true;backend='普通网页搜索';items=await native('rss',{url:'https://www.bing.com/search?'+new URLSearchParams({q,format:'rss',mkt:'zh-CN'}),publisher:'搜索结果'},signal)}
  if(!Array.isArray(items)||!items.length)throw new Error('搜索来源没有返回可用结果，请稍后再试')
  const result=listReply(items,backend,(fallback?'广泛搜索暂时不可达，已改用备用搜索。':'')+'这是网页搜索摘要，未逐篇阅读全文；没有报道日期的结果不能证明最新。');result.status=fallback?'partial':'ok';return result
}
