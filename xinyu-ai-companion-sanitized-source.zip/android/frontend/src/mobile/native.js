const pending = new Map()
let sequence = 0
window.__nativeReply = (id, value, error) => {
  const p = pending.get(String(id)); if (!p) return
  clearTimeout(p.timer); pending.delete(String(id))
  error ? p.reject(new Error(error)) : p.resolve(value)
}
export function native(method, body = {}, signal) {
  if (!window.XinyuNative) return Promise.reject(new Error('请在心屿安卓应用内使用此功能'))
  if (signal?.aborted) return Promise.reject(new DOMException('已打断', 'AbortError'))
  const id = String(++sequence)
  return new Promise((resolve, reject) => {
    const cleanup = () => signal?.removeEventListener('abort', abort)
    const abort = () => {
      clearTimeout(pending.get(id)?.timer); pending.delete(id); cleanup()
      window.XinyuNative.cancel(id); reject(new DOMException('已打断', 'AbortError'))
    }
    pending.set(id, { resolve: v => { cleanup(); resolve(v) }, reject: e => { cleanup(); reject(e) },
      timer: setTimeout(() => { window.XinyuNative.cancel(id); pending.delete(id); cleanup(); reject(new Error('等待超时，请检查网络后重试')) }, method === 'speak' ? 600000 : method === 'reachProbe' ? 180000 : 90000) })
    signal?.addEventListener('abort', abort, { once: true })
    window.XinyuNative.call(id, method, JSON.stringify(body))
  })
}
export const net = (url, signal) => native('get', { url }, signal)
