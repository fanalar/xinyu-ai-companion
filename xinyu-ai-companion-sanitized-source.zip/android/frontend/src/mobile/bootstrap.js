import {service} from './service.js'
if (!crypto.randomUUID) crypto.randomUUID = () => {
  const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128
  const h=[...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20)
}
const originalFetch=window.fetch.bind(window)
window.fetch=async(input,options={})=>{
  const url=typeof input==='string'?input:input.url
  if(!url.startsWith('/api/'))return originalFetch(input,options)
  const path=url.split('?')[0]
  try {const result=await service(path,options.method||'GET',options.body?JSON.parse(options.body):{},options.signal);return new Response(JSON.stringify(result),{status:200,headers:{'Content-Type':'application/json'}})}
  catch(e){if(e.name==='AbortError')throw e;return new Response(JSON.stringify({detail:e.message}),{status:400,headers:{'Content-Type':'application/json'}})}
}
// Android shrinks the activity for the keyboard; this also covers browsers used for UI QA.
const resize=()=>document.documentElement.style.setProperty('--app-height',(window.visualViewport?.height||window.innerHeight)+'px')
window.visualViewport?.addEventListener('resize',resize);window.addEventListener('resize',resize);resize()
