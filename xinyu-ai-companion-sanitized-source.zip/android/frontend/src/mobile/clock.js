import {native,net} from './native.js'
export const isDateQuery=text=>! /新闻|资讯|天气|提醒|生日|纪念|约会/.test(text)&&/今天.*(日期|几号|几月|星期|周几|农历)|现在.*(时间|几点|日期)|明天.*(几号|星期|周几)|后天.*(几号|星期|周几)|^(日期|时间|几点了|今天几号|今天星期几)[？?。！!]*$/.test(text.trim())
export function chinaParts(now=new Date()){
  const date=new Date(now.getTime()+8*3600000)
  return {y:date.getUTCFullYear(),m:date.getUTCMonth()+1,d:date.getUTCDate(),day:date.getUTCDay(),time:date.toISOString().slice(11,16),date:date.toISOString().slice(0,10)}
}
export async function currentClock(signal){
  try{const c=await native('clock',{},signal);if(Number.isFinite(c.now_ms)&&c.now_ms>0)return c}catch(e){if(signal?.aborted)throw e}
  return {now_ms:Date.now(),verified:false,source:'手机系统时间'}
}
export async function lunarOf(date,signal){
  try{const raw=JSON.parse(await net('https://data.weather.gov.hk/weatherAPI/opendata/lunardate.php?date='+date,signal));const lunar=String(raw.LunarDate||'').replace('閏','闰');return /闰?[正一二三四五六七八九十冬腊]+月[初十廿卅一二三四五六七八九]+/.test(lunar)?lunar:''}catch(e){if(signal?.aborted)throw e;return ''}
}
export async function dateReply(text,signal){
  const clock=await currentClock(signal),offset=text.includes('后天')?2:text.includes('明天')?1:0,p=chinaParts(new Date(clock.now_ms+offset*86400000)),lunar=await lunarOf(p.date,signal)
  const label=offset===2?'后天':offset===1?'明天':'今天'
  return {kind:'date',status:clock.verified?'ok':'partial',sources:[],checked_at:new Date(clock.now_ms).toISOString(),clock,reply:`${label}是${p.y}年${p.m}月${p.d}日，星期${'日一二三四五六'[p.day]}${lunar?'，农历'+lunar:''}。${offset?'':'现在是北京时间'+p.time+'。'}\n${clock.verified?'时间已通过联网核对。':'联网校时暂未成功，以上依据手机系统时间；请检查手机是否开启自动日期和时间。'}`}
}
