import { native, net } from './native.js'
import {chinaParts,currentClock,lunarOf} from './clock.js'
import {expandedNews,reachSettings} from './reach.js'
const media = /新华社|新华网|央视|中国新闻网|中新网|人民日报|人民网|经济日报|科技日报|央广|中国日报|财联社|第一财经|澎湃|界面|证券时报|证券日报|上海证券报|中国证券报|每日经济|21世纪经济|新浪|36氪|IT之家|量子位|机器之心|华尔街见闻|钛媒体|BBC|Reuters|路透|美联社|AP News|CNBC|TechCrunch|Bloomberg|彭博|金融时报|Financial Times|RFI|德国之声|美国之音/i
const mediaDomains=['news.cn','xinhuanet.com','cctv.com','chinanews.com.cn','people.com.cn','cnr.cn','chinadaily.com.cn','stcn.com','cls.cn','thepaper.cn','yicai.com','jiemian.com','sina.com.cn','ithome.com','36kr.com','reuters.com','apnews.com','bbc.com','bbc.co.uk','rfi.fr']
const trustedMedia=it=>media.test(it.publisher)||[it.publisher,it.source_url].some(s=>{try{const h=new URL(String(s).includes('://')?s:'https://'+s).hostname;return mediaDomains.some(d=>h===d||h.endsWith('.'+d))}catch{return false}})
export const topicOf = text => {
  if(/人工智能|\bai\b|大模型|智能体|chatgpt|openai/i.test(text))return '人工智能'
  for(const t of ['新能源汽车','科技','财经','体育','汽车','军事','金融','教育','文化','娱乐','房地产','半导体','机器人'])if(text.includes(t))return t
  if(/(国内外|国际|国内|国外|海外|世界|全球|每日|日常|综合)(的)?(新闻|资讯|头条)|新闻和资讯/.test(text))return ''
  return text.replace(/\d{4}年|\d{1,2}月\d{1,2}[日号]|能不能|可不可以|可以|麻烦|帮我|请|一下|一些|查查|查询|搜索|联网|上网|给我|我想听|我想看|我想|听听|说说|告诉我|播报|播一下|播|读一下|念一下|讲讲|看看|介绍|相关|每日|每天|今天|今日|昨天|最新|最近|近一周|这周|国内外|国内|国外|国际|中国|世界|全球|有什么|有哪些|新闻|资讯|头条|早报|晚报|简报|的|查|[？?，,。!！\s]/g,'').slice(0,60)
}
export function newsRange(text,now){
  const p=chinaParts(new Date(now)),midnight=Date.parse(p.date+'T00:00:00+08:00')
  if(/明天|后天/.test(text))return {future:true,label:'未来日期'}
  const explicit=text.match(/(?:(\d{4})年)?(\d{1,2})月(\d{1,2})[日号]/)
  if(explicit){const y=Number(explicit[1]||p.y),m=Number(explicit[2]),d=Number(explicit[3]),day=`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`,start=Date.parse(day+'T00:00:00+08:00');if(!Number.isFinite(start)||chinaParts(new Date(start)).date!==day)return {invalid:true};return {after:start,before:Math.min(now,start+86400000),future:start>now,label:day}}
  if(/昨天/.test(text))return {after:midnight-86400000,before:midnight,label:'昨天'}
  if(/今天|今日/.test(text))return {after:midnight,before:now,label:'今天'}
  if(/近一周|最近一周|这周/.test(text))return {after:now-7*86400000,before:now,label:'近7天'}
  return {after:now-48*3600000,before:now,label:'近48小时'}
}
export function selectNews(items, topic = '', limit = 12, now = Date.now(),range={after:now-48*3600000,before:now}) {
  const chosen = [], seen = new Set()
  for (const it of [...items].sort((a,b)=>Date.parse(b.published_at)-Date.parse(a.published_at))) {
    const age = now - Date.parse(it.published_at)
    if (!Number.isFinite(age) || Date.parse(it.published_at)<range.after || Date.parse(it.published_at)>(range.before>=now?range.before+600000:range.before-1)) continue
    if (/联系我们|联系电话|地址信息|爱企查|地图|招生|认证项目|招商|精彩回顾|域名.*注册|优惠|代办|Moomoo|第[一二三四五六七八九十\d]+天[：:]/i.test(it.title)) continue
    if (it.aggregator && !trustedMedia(it)) continue
    if (topic === '人工智能' ? !/人工智能|\bai\b|openai|大模型|智能体|chatgpt|gpt|算力|机器学习/i.test(it.title) : topic && !it.title.toLowerCase().includes(topic.toLowerCase())) continue
    const title = it.aggregator ? it.title.replace(/\s+-\s+[^-]{2,30}$/, '') : it.title
    const key = title.replace(/[^\p{L}\p{N}]/gu,'').toLowerCase()
    // Bigram overlap filters copies of the same headline with small editorial changes.
    const grams = new Set(Array.from(key).slice(1).map((_,i)=>key.slice(i,i+2)))
    if (seen.has(it.url) || chosen.some(c => {const g=c.grams;return key===c.key || (2*[...grams].filter(x=>g.has(x)).length/Math.max(1,g.size+grams.size)>.76)})) continue
    chosen.push({...it,title, key,grams}); seen.add(it.url)
    if (chosen.length>=limit) break
  }
  return chosen.map(({key,grams,...it})=>it)
}
export async function bulletin(text, signal) {
  const topic=topicOf(text), labels={china:'国内',society:'社会',finance:'财经',world:'国际','scroll-news':'即时',importnews:'要闻',culture:'文娱',sports:'体育'}
  const categories=topic ? ['scroll-news','finance'] : /国外|国际|海外|世界|全球/.test(text)&&!text.includes('国内外') ? ['world'] : /国内|中国/.test(text)&&!text.includes('国内外') ? ['china','society','finance'] : ['china','society','finance','world']
  if(topic==='体育')categories.push('sports');if(/文化|娱乐/.test(topic))categories.push('culture')
  const requests=categories.map(c=>({name:'中国新闻网·'+labels[c],method:'rss',body:{url:`https://www.chinanews.com.cn/rss/${c}.xml`,publisher:`中国新闻网·${labels[c]}`}}))
  requests.push({name:'中新关键词搜索',method:'newsSearch',body:{query:topic,channel:categories.length===1&&categories[0]==='world'?'gj':/国内|中国/.test(text)&&!text.includes('国内外')?'gn':'all'}})
  const [results,extra]=await Promise.all([Promise.allSettled(requests.map(r=>native(r.method,r.body,signal))),expandedNews(text,topic,signal)])
  if(signal?.aborted)throw new DOMException('已打断','AbortError')
  const clock=await currentClock(signal),now=clock.now_ms,parts=chinaParts(new Date(now)),range=newsRange(text,now),checked_at=new Date(now).toISOString()
  const source_checks=[...requests.map((r,i)=>({source:r.name,status:results[i].status==='fulfilled'?'connected':'unreachable',count:results[i].status==='fulfilled'&&Array.isArray(results[i].value)?results[i].value.length:0})),...extra.checks]
  const base={kind:'news',bulletin:true,checked_at,clock,source_checks}
  if(range.future||range.invalid)return {...base,status:'clarification',sources:[],reply:`今天是${parts.y}年${parts.m}月${parts.d}日（北京时间）。${range.future?'未来的新闻尚未发生，不能当作事实播报。':'这个日期无效，请检查月份和日期。'}可以说“播报今天的新闻”。`}
  let pool=[...results.flatMap(r=>r.status==='fulfilled'&&Array.isArray(r.value)?r.value:[]),...extra.items],items=selectNews(pool,topic,12,now,range)
  if(items.length<4){
    if(reachSettings().public_search)try{const more=await native('reachSearch',{query:`${parts.date} ${range.label} ${topic|| (categories[0]==='world'?'国际':'国内外')} 新闻报道，原始媒体与发布时间`},signal);pool.push(...more);source_checks.push({source:'Exa广泛新闻搜索',status:'connected',count:more.length});items=selectNews(pool,topic,12,now,range)}catch(e){if(signal?.aborted)throw e;source_checks.push({source:'Exa广泛新闻搜索',status:'unreachable',count:0})}
    try{const more=await native('rss',{url:'https://news.google.com/rss/search?'+new URLSearchParams({q:(topic|| (categories[0]==='world'?'国际新闻':'新闻'))+' when:7d',hl:'zh-CN',gl:'CN',ceid:'CN:zh-Hans'}),publisher:'Google新闻',aggregator:true},signal);pool.push(...more);source_checks.push({source:'Google新闻备用',status:'connected',count:more.length});items=selectNews(pool,topic,12,now,range)}catch(e){if(signal?.aborted)throw e;source_checks.push({source:'Google新闻备用',status:'unreachable',count:0})}
  }
  if(!topic&&categories.length===4){const balanced=categories.flatMap(c=>selectNews(pool.filter(i=>i.publisher==='中国新闻网·'+labels[c]),'',3,now,range));items=selectNews([...balanced,...items],'',12,now,range)}
  const connected=source_checks.some(r=>r.status==='connected'),partial=source_checks.some(r=>r.status==='unreachable')||!clock.verified
  const clockNote=clock.verified?'':'手机时间未能联网核对；请检查自动日期和时间。'
  if(!items.length)return {...base,status:'error',sources:[],reply:`当前日期：${parts.y}年${parts.m}月${parts.d}日（北京时间）。\n${connected?`已经联网，但没有检索到${range.label}与“${topic||'新闻'}”匹配、且有明确报道时间的结果。可换成“今日国内新闻”或“近一周${topic||'国际'}新闻”。`:'新闻来源均未连接成功，请检查手机网络后再试。'}${clockNote}`}
  const lunar=await lunarOf(parts.date,signal)
  const lead=`${parts.m}月${parts.d}日，每日${topic?topic+'资讯':'新闻'}，星期${'日一二三四五六'[parts.day]}，${lunar?'农历'+lunar:'农历暂未核实'}，${[0,6].includes(parts.day)?'周末愉快！':'愿你今天顺心！'}`
  const numbered=items.map((i,n)=>`${n+1}、${i.title.replace(/。$/,'')}。`).join('\n')
  const quote='留一点时间给自己，慢慢走也算向前。愿今天的小小进步，带来明天的从容。'
  const scope=`${parts.y}年，截至北京时间${parts.time}，${range.label}精选${items.length}条。${items.length<12?'符合条件的消息不足12条，按实际数量播报。':''}${source_checks.some(r=>r.status==='unreachable')?'部分来源暂时不可达，已使用可连通来源。':''}${clockNote}`
  return {...base,status:partial?'partial':'ok',sources:items,topic,item_count:items.length,lunar,window_hours:(range.before-range.after)/3600000,requested_range:range.label,reply:lead+'\n'+scope+'\n\n'+numbered+'\n\n【微语】'+quote,speech_text:lead+'\n'+scope+'\n'+numbered+'\n今日微语。'+quote}
}
export function cityOf(text) { return text.split(/天气|气温|下雨|降雨|weather/i)[0].replace(/^(请|麻烦|能不能|可以|帮我|给我|我想|想知道|查询|查一下|查一查|查查|看看|查|问一下|联网|搜索|上网|一下)+/,'').replace(/今天|明天|后天|现在|未来[一二三四五六七\d]+天|这周|一周|周末|的|是否|会不会|会|怎么样|如何|怎样/g,'').trim().slice(0,60) }
export const weatherDesc=c=>c===0?'晴':[1,2].includes(c)?'多云':c===3?'阴':[45,48].includes(c)?'雾':[51,53,55,56,57].includes(c)?'毛毛雨':[61,63,65,66,67,80,81,82].includes(c)?'雨':[71,73,75,77,85,86].includes(c)?'雪':[95,96,99].includes(c)?'雷雨':'天气代码'+c
export async function weather(text,city,signal){
  const place=cityOf(text)||city, checked_at=new Date().toISOString()
  if(!place)return {kind:'weather',status:'clarification',pending_weather:true,sources:[],checked_at,reply:'你想查哪个城市的天气？例如“北京明天天气”。我不会自动获取你的位置。'}
  const locations=JSON.parse(await net('https://geocoding-api.open-meteo.com/v1/search?'+new URLSearchParams({name:place,count:5,language:'zh',format:'json'}),signal)).results||[]
  if(!locations.length)return {kind:'weather',status:'clarification',pending_weather:true,sources:[],checked_at,reply:`没有找到“${place}”。请说城市全名；海外城市也可以用英文名。`}
  const loc=locations.sort((a,b)=>(b.population||0)-(a.population||0))[0]
  const data=JSON.parse(await net('https://api.open-meteo.com/v1/forecast?'+new URLSearchParams({latitude:loc.latitude,longitude:loc.longitude,current:'temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m',daily:'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',forecast_days:7,timezone:'auto'}),signal))
  const cur=data.current,d=data.daily;const name=[...new Set([loc.name,loc.admin1,loc.country].filter(Boolean))].join(' · ')
  const lines=[`${name}（${data.timezone}）`,`天气模型当前值 ${cur.time}：${weatherDesc(cur.weather_code)}，${cur.temperature_2m}℃，风速${cur.wind_speed_10m} km/h。`]
  const ids=text.includes('明天')?[1]:text.includes('后天')?[2]:/一周|七天|7天|下周|下个月/.test(text)?[0,1,2,3,4,5,6]:/未来|三天|3天/.test(text)?[0,1,2]:[0]
  if(/下周|下个月/.test(text))lines.push('当前查询覆盖未来7天，不代表更远日期。')
  for(const i of ids)lines.push(`${d.time[i]}：${weatherDesc(d.weather_code[i])}，${d.temperature_2m_min[i]}～${d.temperature_2m_max[i]}℃，最高降水概率${d.precipitation_probability_max[i]}%。`)
  lines.push('来源：Open-Meteo。预报会变化，模型当前值不等同于气象站实测。')
  return {kind:'weather',status:'ok',city:place,checked_at,sources:[{title:'Open-Meteo天气数据',url:'https://open-meteo.com/en/docs',publisher:'Open-Meteo',published_at:cur.time}],reply:lines.join('\n')}
}
