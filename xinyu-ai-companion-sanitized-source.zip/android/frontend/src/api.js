import {native} from './mobile/native.js'
const request=async(path,method='GET',body,signal)=>{const r=await fetch(path,{method,body:body?JSON.stringify(body):undefined,signal});const data=await r.json();if(!r.ok)throw new Error(data.detail||'操作失败');return data}
export const api={
  state:()=>request('/api/state'),saveCompanion:c=>request('/api/companion','POST',c),
  chat:(text,o={})=>request('/api/chat','POST',{text,client_id:o.clientId,profile_id:o.profileId},o.signal),
  createProfile:d=>request('/api/profiles','POST',d),switchProfile:id=>request('/api/profiles/'+id+'/activate','POST',{}),
  memories:()=>request('/api/memories'),addMemory:content=>request('/api/memories','POST',{content}),
  deleteMemory:id=>request('/api/memories/'+id,'DELETE'),editMemory:(id,content)=>request('/api/memories/'+id,'POST',{content}),
  connection:()=>request('/api/connection'),saveConnection:d=>request('/api/connection','POST',d),testConnection:()=>request('/api/connection/test','POST',{}),
  diagnostics:()=>request('/api/diagnostics'),entitlements:()=>request('/api/entitlements'),
  cancel:client_id=>request('/api/chat/cancel','POST',{client_id}),reset:mode=>request('/api/reset','POST',{mode}),
  generateAvatar:prompt=>request('/api/avatar/generate','POST',{prompt}),
  exportData:async()=>downloadJson(await request('/api/export'),'心屿-陪伴记录.json')
}
export function downloadJson(data,filename){return native('export',{text:JSON.stringify(data,null,2),filename})}
export const copyMessage = text => native('copy',{text})
export const avatarUrl=()=>null
window.__xinyuLip={level:0}
window.__xinyuVoicePolicy={requested:'speaker',effective:'speaker',available:false}
window.__nativeVoicePolicy=policy=>{window.__xinyuVoicePolicy=policy;window.dispatchEvent(new Event('xinyu-voice-policy'))}
let generation=0
window.__nativeSpeech=type=>{window.__xinyuSpeaking=type==='start';window.__xinyuLip={level:type==='start'?.35:0};window.dispatchEvent(new Event('xinyu-speech-change'));if(type==='start')window.dispatchEvent(new Event('xinyu-speaking'))}
function playback(active){window.__xinyuPlaybackActive=active;window.dispatchEvent(new Event('xinyu-playback'))}
export function stopSpeaking(){generation++;window.XinyuNative?.stopSpeech();playback(false);window.__xinyuSpeaking=false;window.__xinyuLip={level:0};window.dispatchEvent(new Event('xinyu-speech-change'))}
export async function speak(text,opts={}){
  stopSpeaking();const g=generation,session='play-'+g
  if(opts.signal?.aborted)return false
  const playing=()=>opts.onPlaying?.();window.addEventListener('xinyu-speaking',playing)
  const chunks=String(text).split(/\n+/).filter(s=>s.trim()).flatMap(s=>Array.from({length:Math.ceil(s.length/240)},(_,i)=>s.slice(i*240,(i+1)*240)))
  if(!chunks.length){window.removeEventListener('xinyu-speaking',playing);return false}
  playback(true)
  try{
    await native('speechBegin',{session},opts.signal)
    for(const chunk of chunks){
      if(g!==generation||opts.signal?.aborted)return false
      const result=await native('speak',{text:chunk,session,rate:opts.rate||localStorage.getItem('xinyu_rate')||'+0%'},opts.signal)
      if(g!==generation||!result.ok)return false
    }return true
  }finally{
    window.removeEventListener('xinyu-speaking',playing)
    if(g===generation)playback(false)
    await native('speechEnd',{session}).catch(()=>{})
  }
}
