import React,{useEffect,useRef,useState} from 'react'
import Icon from './Icon.jsx'
import {charFile} from '../lib/characters.js'
import {isOnlineQuery} from '../lib/online.js'
import {copyMessage} from '../api.js'

export default function ImmersiveCompanion({boot,companion,level,messages,hfOn,hfState,captureReady,playbackActive,voicePolicy,micLevel,err,sending,onSend,onInterrupt,onToggleHf,onSettings,onDress,onHistory,onNavigate,onRetry,autoplay,onToggleAutoplay}){
  const [input,setInput]=useState(''),[captionOn,setCaptionOn]=useState(true),[detail,setDetail]=useState(null),[notice,setNotice]=useState(''),[keyboard,setKeyboard]=useState(false),[talking,setTalking]=useState(false)
  const idle=useRef(null),talk=useRef(null),field=useRef(null),initialHeight=useRef(window.innerHeight)
  const cid=companion.char||'f3',recent=messages.slice(-3)
  useEffect(()=>{const resize=()=>{initialHeight.current=Math.max(initialHeight.current,window.innerHeight);setKeyboard((window.visualViewport?.height||innerHeight)<initialHeight.current*.72)};window.visualViewport?.addEventListener('resize',resize);window.addEventListener('resize',resize);return()=>{window.visualViewport?.removeEventListener('resize',resize);window.removeEventListener('resize',resize)}},[])
  useEffect(()=>{const update=()=>setTalking(!!window.__xinyuSpeaking);window.addEventListener('xinyu-speech-change',update);update();return()=>window.removeEventListener('xinyu-speech-change',update)},[])
  useEffect(()=>{const active=talking?talk.current:idle.current,other=talking?idle.current:talk.current;active?.play().catch(()=>{});other?.pause()},[talking,cid])
  useEffect(()=>{const focus=()=>field.current?.focus();window.addEventListener('xinyu-focus-chat',focus);return()=>window.removeEventListener('xinyu-focus-chat',focus)},[])
  useEffect(()=>{const key=e=>{if(e.key==='Escape')setDetail(null)};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key)},[])
  const busy=playbackActive||sending||['thinking','preparing','transcribing'].includes(hfState)
  const state=!hfOn?'麦克风已暂停':playbackActive?companion.name+'正在说话':!captureReady?'余音保护 · 随后继续听':({connecting:'正在开启麦克风',listening:'我在听',hearing:'正在听你说',thinking:'正在想怎么回应',preparing:'正在准备语音',transcribing:'正在识别',error:'麦克风需要检查'}[hfState]||'我在听')
  const send=()=>{if(!input.trim())return;onSend(input);setInput('');field.current?.blur()}
  return <section className={'immersive-companion'+(keyboard?' keyboard-open':'')} aria-label="全屏陪伴">
    <div className={'immersive-avatar'+(talking?' talking':'')} aria-hidden="true">
      <img src={charFile(cid)} alt=""/>
      
      
    </div>
    <div className="immersive-shade" aria-hidden="true"/>
    <header className="immersive-head"><button className="immersive-person" aria-label="切换伙伴" onClick={()=>onNavigate('home')}><span>{companion.name}</span><small><i/>{level} · 在你身边</small></button><div className="immersive-tools"><button aria-label="装扮" onClick={onDress}><Icon name="dress"/></button><button aria-label="陪伴设置" onClick={onSettings}><Icon name="settings"/></button></div></header>
    <div className="immersive-actions"><button aria-label="聊天记录" onClick={onHistory}><Icon name="chat" size={19}/></button><button aria-label={captionOn?'隐藏字幕':'显示字幕'} aria-pressed={captionOn} onClick={()=>setCaptionOn(v=>!v)}>字</button><button aria-label="切换自动朗读" aria-pressed={autoplay} onClick={onToggleAutoplay}><Icon name={autoplay?'sound':'mute'} size={19}/></button></div>
    <div className="immersive-bottom">
      {captionOn&&<div className="floating-captions" aria-label="最近对话" aria-live="polite">
        {!recent.length&&<div className="caption-greeting">我在这里。今天，想和我聊点什么？</div>}
        {recent.map((m,i)=><button key={m.id} className={'floating-caption '+(m.role==='user'?'user':'assistant')+(i===recent.length-1?' latest':'')} aria-label={'查看'+(m.role==='user'?'我的':companion.name+'的')+'这条对话全文'} onClick={()=>setDetail(m)}><span className="caption-who">{m.role==='user'?'我':companion.name}</span><span className="caption-text">{m.content}</span>{(m.content.length>90||m.online)&&<span className="caption-expand">全文 {m.online?'· 来源 ':''}↗</span>}</button>)}
      </div>}
      {err&&<div className="immersive-error" role="alert"><span>{err}</span><button onClick={/模型|密钥|服务|回复/.test(err)?()=>onSettings('connect'):onRetry}>{/模型|密钥|服务|回复/.test(err)?'连接设置':'重试'}</button></div>}
      {!boot.llm_ready&&!err&&<button className="immersive-connect" onClick={()=>onSettings('connect')}>连接模型开始聊天 · 天气与新闻可直接查 <span>↗</span></button>}
      <div className="immersive-voice" role="status"><span className="tiny-meter" aria-hidden="true">{[0,1,2].map(i=><i key={i} style={{height:(hfOn?4+micLevel*(12+i*3):3)+'px'}}/>)}</span><span>{state}</span><small>{voicePolicy?.effective==='headphones'?'耳机 · 开口可打断':'外放防回声'}</small></div>
      <div className="immersive-controls"><div className="immersive-input"><input ref={field} aria-label="聊天消息" value={input} maxLength={2000} placeholder={'想对'+companion.name+'说点什么…'} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.nativeEvent.isComposing){e.preventDefault();send()}}}/><button aria-label="发送消息" disabled={!input.trim()||(!boot.llm_ready&&!isOnlineQuery(input)&&!boot.weather_pending)} onClick={send}><Icon name="arrow" size={20}/></button></div>{busy&&<button className="immersive-interrupt" aria-label="打断回复" onClick={onInterrupt}><Icon name="stop" size={18}/></button>}<button className={'immersive-mic'+(!hfOn?' off':'')} aria-label={hfOn?'暂停麦克风':'开启麦克风'} onClick={onToggleHf}><Icon name={hfOn?'mic':'mute'} size={20}/></button></div>
      {busy&&voicePolicy?.effective!=='headphones'&&<div className="immersive-turn-hint">想插话，点停止；等「我在听」后开口</div>}
      <nav className="immersive-nav" aria-label="应用导航">{[['companion','heart','陪伴'],['home','home','遇见'],['memory','memory','记忆'],['pet','pet','小窝'],['mine','user','我们']].map(([id,ic,label])=><button key={id} aria-label={label} aria-current={id==='companion'?'page':undefined} onClick={()=>onNavigate(id)}><Icon name={ic} size={17}/><span>{label}</span></button>)}</nav>
    </div>
    {detail&&<div className="caption-detail-mask" onClick={e=>{if(e.target===e.currentTarget)setDetail(null)}}><section className="caption-detail" role="dialog" aria-modal="true" aria-label="对话全文"><header><div><small>这一句，慢慢看</small><h3>{detail.role==='user'?'我':companion.name}</h3></div><button aria-label="关闭对话全文" onClick={()=>{setDetail(null);setNotice('')}}><Icon name="close"/></button></header><div className="caption-detail-content"><p>{detail.content}</p>{detail.online?.sources?.length>0&&<details><summary>查看新闻与资讯来源</summary>{detail.online.sources.map((s,i)=><a key={s.url+i} href={s.url} target="_blank" rel="noreferrer">{i+1}. {s.title}<small>{s.publisher}{s.published_at?' · '+new Date(s.published_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}):''}</small></a>)}</details>}</div><footer><button onClick={()=>copyMessage(detail.content).then(()=>setNotice('已复制')).catch(()=>setNotice('复制失败'))}><Icon name="copy" size={16}/>复制</button><button onClick={()=>{setDetail(null);onHistory()}}>完整聊天记录 <span>→</span></button></footer>{notice&&<small role="status">{notice}</small>}</section></div>}
  </section>
}
